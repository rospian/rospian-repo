// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from actuator_msgs:msg/ActuatorsLinearVelocity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "actuator_msgs/msg/actuators_linear_velocity.h"


#ifndef ACTUATOR_MSGS__MSG__DETAIL__ACTUATORS_LINEAR_VELOCITY__STRUCT_H_
#define ACTUATOR_MSGS__MSG__DETAIL__ACTUATORS_LINEAR_VELOCITY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'velocity'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/ActuatorsLinearVelocity in the package actuator_msgs.
/**
  * This message defines lowest level commands to be sent
  * to the actuator(s) for linear velocity.
 */
typedef struct actuator_msgs__msg__ActuatorsLinearVelocity
{
  /// Velocity of the actuators in
  rosidl_runtime_c__double__Sequence velocity;
} actuator_msgs__msg__ActuatorsLinearVelocity;

// Struct for a sequence of actuator_msgs__msg__ActuatorsLinearVelocity.
typedef struct actuator_msgs__msg__ActuatorsLinearVelocity__Sequence
{
  actuator_msgs__msg__ActuatorsLinearVelocity * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} actuator_msgs__msg__ActuatorsLinearVelocity__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ACTUATOR_MSGS__MSG__DETAIL__ACTUATORS_LINEAR_VELOCITY__STRUCT_H_
