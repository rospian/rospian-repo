// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from actuator_msgs:msg/ActuatorsAngularVelocity.idl
// generated code does not contain a copyright notice

#include "actuator_msgs/msg/detail/actuators_angular_velocity__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_actuator_msgs
const rosidl_type_hash_t *
actuator_msgs__msg__ActuatorsAngularVelocity__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x0b, 0xa1, 0xbe, 0xd9, 0x2a, 0x42, 0x50, 0xb2,
      0xa6, 0xd6, 0xf1, 0x1a, 0x2b, 0xd7, 0xba, 0x29,
      0x24, 0x0d, 0x7f, 0x40, 0xe4, 0xdb, 0x97, 0xed,
      0xca, 0x4d, 0x0c, 0xbc, 0x84, 0x07, 0x23, 0x68,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char actuator_msgs__msg__ActuatorsAngularVelocity__TYPE_NAME[] = "actuator_msgs/msg/ActuatorsAngularVelocity";

// Define type names, field names, and default values
static char actuator_msgs__msg__ActuatorsAngularVelocity__FIELD_NAME__velocity[] = "velocity";

static rosidl_runtime_c__type_description__Field actuator_msgs__msg__ActuatorsAngularVelocity__FIELDS[] = {
  {
    {actuator_msgs__msg__ActuatorsAngularVelocity__FIELD_NAME__velocity, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
actuator_msgs__msg__ActuatorsAngularVelocity__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {actuator_msgs__msg__ActuatorsAngularVelocity__TYPE_NAME, 42, 42},
      {actuator_msgs__msg__ActuatorsAngularVelocity__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# This message defines lowest level commands to be sent\n"
  "# to the actuator(s) for angular velocity.\n"
  "\n"
  "float64[] velocity\\t\\t# Velocity of the actuators in [rad/s]";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
actuator_msgs__msg__ActuatorsAngularVelocity__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {actuator_msgs__msg__ActuatorsAngularVelocity__TYPE_NAME, 42, 42},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 159, 159},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
actuator_msgs__msg__ActuatorsAngularVelocity__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *actuator_msgs__msg__ActuatorsAngularVelocity__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
