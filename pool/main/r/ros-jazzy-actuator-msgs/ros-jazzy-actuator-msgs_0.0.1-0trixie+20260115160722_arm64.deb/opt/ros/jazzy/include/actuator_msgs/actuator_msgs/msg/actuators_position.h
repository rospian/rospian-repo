// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:msg/ActuatorsPosition.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATORS_POSITION_H_
#define ACTUATOR_MSGS__MSG__ACTUATORS_POSITION_H_

#include "actuator_msgs/msg/detail/actuators_position__struct.h"
#include "actuator_msgs/msg/detail/actuators_position__functions.h"
#include "actuator_msgs/msg/detail/actuators_position__type_support.h"

#endif  // ACTUATOR_MSGS__MSG__ACTUATORS_POSITION_H_
