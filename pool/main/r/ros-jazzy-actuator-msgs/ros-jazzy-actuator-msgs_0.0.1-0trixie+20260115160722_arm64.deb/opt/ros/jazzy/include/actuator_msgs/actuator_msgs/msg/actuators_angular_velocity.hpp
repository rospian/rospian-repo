// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_VELOCITY_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_VELOCITY_HPP_

#include "actuator_msgs/msg/detail/actuators_angular_velocity__struct.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_velocity__builder.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_velocity__traits.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_velocity__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_VELOCITY_HPP_
