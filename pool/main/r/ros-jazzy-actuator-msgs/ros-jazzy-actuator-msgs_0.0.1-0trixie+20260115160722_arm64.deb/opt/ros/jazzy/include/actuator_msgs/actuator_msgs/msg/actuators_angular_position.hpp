// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_POSITION_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_POSITION_HPP_

#include "actuator_msgs/msg/detail/actuators_angular_position__struct.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_position__builder.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_position__traits.hpp"
#include "actuator_msgs/msg/detail/actuators_angular_position__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATORS_ANGULAR_POSITION_HPP_
