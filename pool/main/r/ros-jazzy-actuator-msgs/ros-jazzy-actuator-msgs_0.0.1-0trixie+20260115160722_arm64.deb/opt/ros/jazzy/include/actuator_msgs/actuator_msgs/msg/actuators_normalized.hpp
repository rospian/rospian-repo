// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATORS_NORMALIZED_HPP_
#define ACTUATOR_MSGS__MSG__ACTUATORS_NORMALIZED_HPP_

#include "actuator_msgs/msg/detail/actuators_normalized__struct.hpp"
#include "actuator_msgs/msg/detail/actuators_normalized__builder.hpp"
#include "actuator_msgs/msg/detail/actuators_normalized__traits.hpp"
#include "actuator_msgs/msg/detail/actuators_normalized__type_support.hpp"

#endif  // ACTUATOR_MSGS__MSG__ACTUATORS_NORMALIZED_HPP_
