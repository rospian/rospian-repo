// generated from rosidl_generator_c/resource/idl.h.em
// with input from actuator_msgs:msg/Actuators.idl
// generated code does not contain a copyright notice

#ifndef ACTUATOR_MSGS__MSG__ACTUATORS_H_
#define ACTUATOR_MSGS__MSG__ACTUATORS_H_

#include "actuator_msgs/msg/detail/actuators__struct.h"
#include "actuator_msgs/msg/detail/actuators__functions.h"
#include "actuator_msgs/msg/detail/actuators__type_support.h"

#endif  // ACTUATOR_MSGS__MSG__ACTUATORS_H_
