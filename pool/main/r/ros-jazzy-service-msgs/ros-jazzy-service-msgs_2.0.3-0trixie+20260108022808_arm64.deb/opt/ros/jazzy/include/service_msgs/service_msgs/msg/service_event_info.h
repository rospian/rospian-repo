// generated from rosidl_generator_c/resource/idl.h.em
// with input from service_msgs:msg/ServiceEventInfo.idl
// generated code does not contain a copyright notice

#ifndef SERVICE_MSGS__MSG__SERVICE_EVENT_INFO_H_
#define SERVICE_MSGS__MSG__SERVICE_EVENT_INFO_H_

#include "service_msgs/msg/detail/service_event_info__struct.h"
#include "service_msgs/msg/detail/service_event_info__functions.h"
#include "service_msgs/msg/detail/service_event_info__type_support.h"

#endif  // SERVICE_MSGS__MSG__SERVICE_EVENT_INFO_H_
