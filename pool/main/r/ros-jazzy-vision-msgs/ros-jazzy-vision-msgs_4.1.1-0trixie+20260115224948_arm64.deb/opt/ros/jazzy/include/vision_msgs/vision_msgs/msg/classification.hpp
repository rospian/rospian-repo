// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__CLASSIFICATION_HPP_
#define VISION_MSGS__MSG__CLASSIFICATION_HPP_

#include "vision_msgs/msg/detail/classification__struct.hpp"
#include "vision_msgs/msg/detail/classification__builder.hpp"
#include "vision_msgs/msg/detail/classification__traits.hpp"
#include "vision_msgs/msg/detail/classification__type_support.hpp"

#endif  // VISION_MSGS__MSG__CLASSIFICATION_HPP_
