// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__OBJECT_HYPOTHESIS_WITH_POSE_HPP_
#define VISION_MSGS__MSG__OBJECT_HYPOTHESIS_WITH_POSE_HPP_

#include "vision_msgs/msg/detail/object_hypothesis_with_pose__struct.hpp"
#include "vision_msgs/msg/detail/object_hypothesis_with_pose__builder.hpp"
#include "vision_msgs/msg/detail/object_hypothesis_with_pose__traits.hpp"
#include "vision_msgs/msg/detail/object_hypothesis_with_pose__type_support.hpp"

#endif  // VISION_MSGS__MSG__OBJECT_HYPOTHESIS_WITH_POSE_HPP_
