// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__LABEL_INFO_HPP_
#define VISION_MSGS__MSG__LABEL_INFO_HPP_

#include "vision_msgs/msg/detail/label_info__struct.hpp"
#include "vision_msgs/msg/detail/label_info__builder.hpp"
#include "vision_msgs/msg/detail/label_info__traits.hpp"
#include "vision_msgs/msg/detail/label_info__type_support.hpp"

#endif  // VISION_MSGS__MSG__LABEL_INFO_HPP_
