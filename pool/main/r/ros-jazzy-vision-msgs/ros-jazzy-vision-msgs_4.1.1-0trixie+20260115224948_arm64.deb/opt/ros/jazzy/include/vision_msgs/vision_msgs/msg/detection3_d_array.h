// generated from rosidl_generator_c/resource/idl.h.em
// with input from vision_msgs:msg/Detection3DArray.idl
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__DETECTION3_D_ARRAY_H_
#define VISION_MSGS__MSG__DETECTION3_D_ARRAY_H_

#include "vision_msgs/msg/detail/detection3_d_array__struct.h"
#include "vision_msgs/msg/detail/detection3_d_array__functions.h"
#include "vision_msgs/msg/detail/detection3_d_array__type_support.h"

#endif  // VISION_MSGS__MSG__DETECTION3_D_ARRAY_H_
