// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__VISION_CLASS_HPP_
#define VISION_MSGS__MSG__VISION_CLASS_HPP_

#include "vision_msgs/msg/detail/vision_class__struct.hpp"
#include "vision_msgs/msg/detail/vision_class__builder.hpp"
#include "vision_msgs/msg/detail/vision_class__traits.hpp"
#include "vision_msgs/msg/detail/vision_class__type_support.hpp"

#endif  // VISION_MSGS__MSG__VISION_CLASS_HPP_
