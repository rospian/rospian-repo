// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__POINT2_D_HPP_
#define VISION_MSGS__MSG__POINT2_D_HPP_

#include "vision_msgs/msg/detail/point2_d__struct.hpp"
#include "vision_msgs/msg/detail/point2_d__builder.hpp"
#include "vision_msgs/msg/detail/point2_d__traits.hpp"
#include "vision_msgs/msg/detail/point2_d__type_support.hpp"

#endif  // VISION_MSGS__MSG__POINT2_D_HPP_
