// generated from rosidl_generator_c/resource/idl.h.em
// with input from vision_msgs:msg/Classification.idl
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__CLASSIFICATION_H_
#define VISION_MSGS__MSG__CLASSIFICATION_H_

#include "vision_msgs/msg/detail/classification__struct.h"
#include "vision_msgs/msg/detail/classification__functions.h"
#include "vision_msgs/msg/detail/classification__type_support.h"

#endif  // VISION_MSGS__MSG__CLASSIFICATION_H_
