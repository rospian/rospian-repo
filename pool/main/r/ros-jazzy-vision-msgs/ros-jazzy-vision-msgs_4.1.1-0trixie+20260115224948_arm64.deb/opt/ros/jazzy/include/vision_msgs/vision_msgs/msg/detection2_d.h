// generated from rosidl_generator_c/resource/idl.h.em
// with input from vision_msgs:msg/Detection2D.idl
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__DETECTION2_D_H_
#define VISION_MSGS__MSG__DETECTION2_D_H_

#include "vision_msgs/msg/detail/detection2_d__struct.h"
#include "vision_msgs/msg/detail/detection2_d__functions.h"
#include "vision_msgs/msg/detail/detection2_d__type_support.h"

#endif  // VISION_MSGS__MSG__DETECTION2_D_H_
