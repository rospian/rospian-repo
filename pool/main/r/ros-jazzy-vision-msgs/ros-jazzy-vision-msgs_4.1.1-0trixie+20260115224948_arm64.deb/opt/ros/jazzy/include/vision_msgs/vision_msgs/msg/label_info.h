// generated from rosidl_generator_c/resource/idl.h.em
// with input from vision_msgs:msg/LabelInfo.idl
// generated code does not contain a copyright notice

#ifndef VISION_MSGS__MSG__LABEL_INFO_H_
#define VISION_MSGS__MSG__LABEL_INFO_H_

#include "vision_msgs/msg/detail/label_info__struct.h"
#include "vision_msgs/msg/detail/label_info__functions.h"
#include "vision_msgs/msg/detail/label_info__type_support.h"

#endif  // VISION_MSGS__MSG__LABEL_INFO_H_
