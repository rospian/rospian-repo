// generated from rosidl_generator_c/resource/idl.h.em
// with input from trajectory_msgs:msg/JointTrajectory.idl
// generated code does not contain a copyright notice

#ifndef TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_H_
#define TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_H_

#include "trajectory_msgs/msg/detail/joint_trajectory__struct.h"
#include "trajectory_msgs/msg/detail/joint_trajectory__functions.h"
#include "trajectory_msgs/msg/detail/joint_trajectory__type_support.h"

#endif  // TRAJECTORY_MSGS__MSG__JOINT_TRAJECTORY_H_
