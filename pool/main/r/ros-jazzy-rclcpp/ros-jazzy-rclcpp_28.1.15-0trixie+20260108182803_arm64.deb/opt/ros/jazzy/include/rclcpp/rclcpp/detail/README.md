Notice that headers in this folder should only provide symbols in the rclcpp::detail namespace.

Also that these headers are not considered part of the public API and are subject to change without notice.
