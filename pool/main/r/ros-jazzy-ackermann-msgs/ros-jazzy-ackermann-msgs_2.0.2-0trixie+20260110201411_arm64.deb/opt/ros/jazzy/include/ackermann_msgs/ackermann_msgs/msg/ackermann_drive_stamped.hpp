// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_HPP_
#define ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_HPP_

#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__struct.hpp"
#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__builder.hpp"
#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__traits.hpp"
#include "ackermann_msgs/msg/detail/ackermann_drive_stamped__type_support.hpp"

#endif  // ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_STAMPED_HPP_
