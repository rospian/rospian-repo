// generated from rosidl_generator_c/resource/idl.h.em
// with input from ackermann_msgs:msg/AckermannDrive.idl
// generated code does not contain a copyright notice

#ifndef ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_H_
#define ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_H_

#include "ackermann_msgs/msg/detail/ackermann_drive__struct.h"
#include "ackermann_msgs/msg/detail/ackermann_drive__functions.h"
#include "ackermann_msgs/msg/detail/ackermann_drive__type_support.h"

#endif  // ACKERMANN_MSGS__MSG__ACKERMANN_DRIVE_H_
