// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ackermann_msgs:msg/AckermannDriveStamped.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "ackermann_msgs/msg/ackermann_drive_stamped.hpp"


#ifndef ACKERMANN_MSGS__MSG__DETAIL__ACKERMANN_DRIVE_STAMPED__STRUCT_HPP_
#define ACKERMANN_MSGS__MSG__DETAIL__ACKERMANN_DRIVE_STAMPED__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'drive'
#include "ackermann_msgs/msg/detail/ackermann_drive__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ackermann_msgs__msg__AckermannDriveStamped __attribute__((deprecated))
#else
# define DEPRECATED__ackermann_msgs__msg__AckermannDriveStamped __declspec(deprecated)
#endif

namespace ackermann_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AckermannDriveStamped_
{
  using Type = AckermannDriveStamped_<ContainerAllocator>;

  explicit AckermannDriveStamped_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    drive(_init)
  {
    (void)_init;
  }

  explicit AckermannDriveStamped_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    drive(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _drive_type =
    ackermann_msgs::msg::AckermannDrive_<ContainerAllocator>;
  _drive_type drive;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__drive(
    const ackermann_msgs::msg::AckermannDrive_<ContainerAllocator> & _arg)
  {
    this->drive = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> *;
  using ConstRawPtr =
    const ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ackermann_msgs__msg__AckermannDriveStamped
    std::shared_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ackermann_msgs__msg__AckermannDriveStamped
    std::shared_ptr<ackermann_msgs::msg::AckermannDriveStamped_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AckermannDriveStamped_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->drive != other.drive) {
      return false;
    }
    return true;
  }
  bool operator!=(const AckermannDriveStamped_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AckermannDriveStamped_

// alias to use template instance with default allocator
using AckermannDriveStamped =
  ackermann_msgs::msg::AckermannDriveStamped_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ackermann_msgs

#endif  // ACKERMANN_MSGS__MSG__DETAIL__ACKERMANN_DRIVE_STAMPED__STRUCT_HPP_
