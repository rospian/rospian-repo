// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from unique_identifier_msgs:msg/UUID.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "unique_identifier_msgs/msg/uuid.h"


#ifndef UNIQUE_IDENTIFIER_MSGS__MSG__DETAIL__UUID__TYPE_SUPPORT_H_
#define UNIQUE_IDENTIFIER_MSGS__MSG__DETAIL__UUID__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "unique_identifier_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_unique_identifier_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  unique_identifier_msgs,
  msg,
  UUID
)(void);

#ifdef __cplusplus
}
#endif

#endif  // UNIQUE_IDENTIFIER_MSGS__MSG__DETAIL__UUID__TYPE_SUPPORT_H_
