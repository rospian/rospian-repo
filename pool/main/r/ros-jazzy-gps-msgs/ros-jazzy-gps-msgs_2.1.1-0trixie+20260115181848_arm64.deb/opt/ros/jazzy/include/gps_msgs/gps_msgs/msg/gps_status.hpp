// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__GPS_STATUS_HPP_
#define GPS_MSGS__MSG__GPS_STATUS_HPP_

#include "gps_msgs/msg/detail/gps_status__struct.hpp"
#include "gps_msgs/msg/detail/gps_status__builder.hpp"
#include "gps_msgs/msg/detail/gps_status__traits.hpp"
#include "gps_msgs/msg/detail/gps_status__type_support.hpp"

#endif  // GPS_MSGS__MSG__GPS_STATUS_HPP_
