// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__GPS_FIX_HPP_
#define GPS_MSGS__MSG__GPS_FIX_HPP_

#include "gps_msgs/msg/detail/gps_fix__struct.hpp"
#include "gps_msgs/msg/detail/gps_fix__builder.hpp"
#include "gps_msgs/msg/detail/gps_fix__traits.hpp"
#include "gps_msgs/msg/detail/gps_fix__type_support.hpp"

#endif  // GPS_MSGS__MSG__GPS_FIX_HPP_
