// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from gps_msgs:msg/GPSStatus.idl
// generated code does not contain a copyright notice
#ifndef GPS_MSGS__MSG__DETAIL__GPS_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define GPS_MSGS__MSG__DETAIL__GPS_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "gps_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "gps_msgs/msg/detail/gps_status__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
bool cdr_serialize_gps_msgs__msg__GPSStatus(
  const gps_msgs__msg__GPSStatus * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
bool cdr_deserialize_gps_msgs__msg__GPSStatus(
  eprosima::fastcdr::Cdr &,
  gps_msgs__msg__GPSStatus * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
size_t get_serialized_size_gps_msgs__msg__GPSStatus(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
size_t max_serialized_size_gps_msgs__msg__GPSStatus(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
bool cdr_serialize_key_gps_msgs__msg__GPSStatus(
  const gps_msgs__msg__GPSStatus * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
size_t get_serialized_size_key_gps_msgs__msg__GPSStatus(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
size_t max_serialized_size_key_gps_msgs__msg__GPSStatus(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_gps_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, gps_msgs, msg, GPSStatus)();

#ifdef __cplusplus
}
#endif

#endif  // GPS_MSGS__MSG__DETAIL__GPS_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
