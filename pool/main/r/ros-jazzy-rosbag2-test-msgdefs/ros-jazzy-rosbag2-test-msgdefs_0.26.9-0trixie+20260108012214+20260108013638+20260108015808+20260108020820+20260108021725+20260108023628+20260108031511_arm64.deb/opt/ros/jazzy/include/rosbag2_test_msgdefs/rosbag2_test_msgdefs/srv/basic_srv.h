// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_test_msgdefs:srv/BasicSrv.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_H_
#define ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_H_

#include "rosbag2_test_msgdefs/srv/detail/basic_srv__struct.h"
#include "rosbag2_test_msgdefs/srv/detail/basic_srv__functions.h"
#include "rosbag2_test_msgdefs/srv/detail/basic_srv__type_support.h"

#endif  // ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_H_
