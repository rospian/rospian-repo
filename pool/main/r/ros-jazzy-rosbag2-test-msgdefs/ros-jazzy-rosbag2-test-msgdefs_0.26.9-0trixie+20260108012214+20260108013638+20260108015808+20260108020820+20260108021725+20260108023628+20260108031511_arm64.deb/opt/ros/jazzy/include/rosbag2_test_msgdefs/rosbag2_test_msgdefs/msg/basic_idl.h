// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_test_msgdefs:msg/BasicIdl.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__MSG__BASIC_IDL_H_
#define ROSBAG2_TEST_MSGDEFS__MSG__BASIC_IDL_H_

#include "rosbag2_test_msgdefs/msg/detail/basic_idl__struct.h"
#include "rosbag2_test_msgdefs/msg/detail/basic_idl__functions.h"
#include "rosbag2_test_msgdefs/msg/detail/basic_idl__type_support.h"

#endif  // ROSBAG2_TEST_MSGDEFS__MSG__BASIC_IDL_H_
