// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_test_msgdefs:msg/ComplexMsgDependsOnIdl.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_MSG_DEPENDS_ON_IDL_H_
#define ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_MSG_DEPENDS_ON_IDL_H_

#include "rosbag2_test_msgdefs/msg/detail/complex_msg_depends_on_idl__struct.h"
#include "rosbag2_test_msgdefs/msg/detail/complex_msg_depends_on_idl__functions.h"
#include "rosbag2_test_msgdefs/msg/detail/complex_msg_depends_on_idl__type_support.h"

#endif  // ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_MSG_DEPENDS_ON_IDL_H_
