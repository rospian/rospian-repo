// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_test_msgdefs:srv/ComplexSrvIdl.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_IDL_H_
#define ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_IDL_H_

#include "rosbag2_test_msgdefs/srv/detail/complex_srv_idl__struct.h"
#include "rosbag2_test_msgdefs/srv/detail/complex_srv_idl__functions.h"
#include "rosbag2_test_msgdefs/srv/detail/complex_srv_idl__type_support.h"

#endif  // ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_IDL_H_
