// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__MSG__BASIC_MSG_HPP_
#define ROSBAG2_TEST_MSGDEFS__MSG__BASIC_MSG_HPP_

#include "rosbag2_test_msgdefs/msg/detail/basic_msg__struct.hpp"
#include "rosbag2_test_msgdefs/msg/detail/basic_msg__builder.hpp"
#include "rosbag2_test_msgdefs/msg/detail/basic_msg__traits.hpp"
#include "rosbag2_test_msgdefs/msg/detail/basic_msg__type_support.hpp"

#endif  // ROSBAG2_TEST_MSGDEFS__MSG__BASIC_MSG_HPP_
