// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_test_msgdefs:srv/ComplexSrvMsg.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_MSG_H_
#define ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_MSG_H_

#include "rosbag2_test_msgdefs/srv/detail/complex_srv_msg__struct.h"
#include "rosbag2_test_msgdefs/srv/detail/complex_srv_msg__functions.h"
#include "rosbag2_test_msgdefs/srv/detail/complex_srv_msg__type_support.h"

#endif  // ROSBAG2_TEST_MSGDEFS__SRV__COMPLEX_SRV_MSG_H_
