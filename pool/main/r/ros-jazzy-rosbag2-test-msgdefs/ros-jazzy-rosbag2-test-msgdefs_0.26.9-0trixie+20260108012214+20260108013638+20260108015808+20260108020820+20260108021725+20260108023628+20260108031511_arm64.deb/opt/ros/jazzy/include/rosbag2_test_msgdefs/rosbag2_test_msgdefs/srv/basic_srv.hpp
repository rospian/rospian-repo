// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_HPP_
#define ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_HPP_

#include "rosbag2_test_msgdefs/srv/detail/basic_srv__struct.hpp"
#include "rosbag2_test_msgdefs/srv/detail/basic_srv__builder.hpp"
#include "rosbag2_test_msgdefs/srv/detail/basic_srv__traits.hpp"
#include "rosbag2_test_msgdefs/srv/detail/basic_srv__type_support.hpp"

#endif  // ROSBAG2_TEST_MSGDEFS__SRV__BASIC_SRV_HPP_
