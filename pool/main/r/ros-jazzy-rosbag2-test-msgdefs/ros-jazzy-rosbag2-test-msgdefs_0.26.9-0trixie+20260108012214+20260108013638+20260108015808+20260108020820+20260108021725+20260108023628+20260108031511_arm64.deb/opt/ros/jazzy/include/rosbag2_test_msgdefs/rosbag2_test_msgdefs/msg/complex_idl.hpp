// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_IDL_HPP_
#define ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_IDL_HPP_

#include "rosbag2_test_msgdefs/msg/detail/complex_idl__struct.hpp"
#include "rosbag2_test_msgdefs/msg/detail/complex_idl__builder.hpp"
#include "rosbag2_test_msgdefs/msg/detail/complex_idl__traits.hpp"
#include "rosbag2_test_msgdefs/msg/detail/complex_idl__type_support.hpp"

#endif  // ROSBAG2_TEST_MSGDEFS__MSG__COMPLEX_IDL_HPP_
