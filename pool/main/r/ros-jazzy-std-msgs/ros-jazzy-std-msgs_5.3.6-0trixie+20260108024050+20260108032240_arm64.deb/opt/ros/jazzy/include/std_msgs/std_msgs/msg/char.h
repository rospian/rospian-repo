// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/Char.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__CHAR_H_
#define STD_MSGS__MSG__CHAR_H_

#include "std_msgs/msg/detail/char__struct.h"
#include "std_msgs/msg/detail/char__functions.h"
#include "std_msgs/msg/detail/char__type_support.h"

#endif  // STD_MSGS__MSG__CHAR_H_
