// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__INT32_HPP_
#define STD_MSGS__MSG__INT32_HPP_

#include "std_msgs/msg/detail/int32__struct.hpp"
#include "std_msgs/msg/detail/int32__builder.hpp"
#include "std_msgs/msg/detail/int32__traits.hpp"
#include "std_msgs/msg/detail/int32__type_support.hpp"

#endif  // STD_MSGS__MSG__INT32_HPP_
