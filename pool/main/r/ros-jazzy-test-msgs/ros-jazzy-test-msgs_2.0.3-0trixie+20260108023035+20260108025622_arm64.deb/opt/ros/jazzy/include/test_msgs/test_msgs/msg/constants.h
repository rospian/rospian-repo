// generated from rosidl_generator_c/resource/idl.h.em
// with input from test_msgs:msg/Constants.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__CONSTANTS_H_
#define TEST_MSGS__MSG__CONSTANTS_H_

#include "test_msgs/msg/detail/constants__struct.h"
#include "test_msgs/msg/detail/constants__functions.h"
#include "test_msgs/msg/detail/constants__type_support.h"

#endif  // TEST_MSGS__MSG__CONSTANTS_H_
