// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__EMPTY_HPP_
#define TEST_MSGS__MSG__EMPTY_HPP_

#include "test_msgs/msg/detail/empty__struct.hpp"
#include "test_msgs/msg/detail/empty__builder.hpp"
#include "test_msgs/msg/detail/empty__traits.hpp"
#include "test_msgs/msg/detail/empty__type_support.hpp"

#endif  // TEST_MSGS__MSG__EMPTY_HPP_
