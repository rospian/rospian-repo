// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__ACTION__NESTED_MESSAGE_HPP_
#define TEST_MSGS__ACTION__NESTED_MESSAGE_HPP_

#include "test_msgs/action/detail/nested_message__struct.hpp"
#include "test_msgs/action/detail/nested_message__builder.hpp"
#include "test_msgs/action/detail/nested_message__traits.hpp"
#include "test_msgs/action/detail/nested_message__type_support.hpp"

#endif  // TEST_MSGS__ACTION__NESTED_MESSAGE_HPP_
