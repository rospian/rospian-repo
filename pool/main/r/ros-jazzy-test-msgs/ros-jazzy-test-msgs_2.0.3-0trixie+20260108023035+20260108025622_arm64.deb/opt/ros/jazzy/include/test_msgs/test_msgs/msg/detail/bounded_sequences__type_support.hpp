// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from test_msgs:msg/BoundedSequences.idl
// generated code does not contain a copyright notice

#ifndef TEST_MSGS__MSG__DETAIL__BOUNDED_SEQUENCES__TYPE_SUPPORT_HPP_
#define TEST_MSGS__MSG__DETAIL__BOUNDED_SEQUENCES__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "test_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_test_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  test_msgs,
  msg,
  BoundedSequences
)();
#ifdef __cplusplus
}
#endif

#endif  // TEST_MSGS__MSG__DETAIL__BOUNDED_SEQUENCES__TYPE_SUPPORT_HPP_
