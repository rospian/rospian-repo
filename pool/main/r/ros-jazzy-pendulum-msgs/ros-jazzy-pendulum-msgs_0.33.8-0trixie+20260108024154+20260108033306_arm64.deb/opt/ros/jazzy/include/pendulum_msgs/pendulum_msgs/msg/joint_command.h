// generated from rosidl_generator_c/resource/idl.h.em
// with input from pendulum_msgs:msg/JointCommand.idl
// generated code does not contain a copyright notice

#ifndef PENDULUM_MSGS__MSG__JOINT_COMMAND_H_
#define PENDULUM_MSGS__MSG__JOINT_COMMAND_H_

#include "pendulum_msgs/msg/detail/joint_command__struct.h"
#include "pendulum_msgs/msg/detail/joint_command__functions.h"
#include "pendulum_msgs/msg/detail/joint_command__type_support.h"

#endif  // PENDULUM_MSGS__MSG__JOINT_COMMAND_H_
