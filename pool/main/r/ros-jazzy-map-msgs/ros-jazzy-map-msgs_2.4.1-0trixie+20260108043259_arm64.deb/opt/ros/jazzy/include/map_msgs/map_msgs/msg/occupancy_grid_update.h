// generated from rosidl_generator_c/resource/idl.h.em
// with input from map_msgs:msg/OccupancyGridUpdate.idl
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE_H_
#define MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE_H_

#include "map_msgs/msg/detail/occupancy_grid_update__struct.h"
#include "map_msgs/msg/detail/occupancy_grid_update__functions.h"
#include "map_msgs/msg/detail/occupancy_grid_update__type_support.h"

#endif  // MAP_MSGS__MSG__OCCUPANCY_GRID_UPDATE_H_
