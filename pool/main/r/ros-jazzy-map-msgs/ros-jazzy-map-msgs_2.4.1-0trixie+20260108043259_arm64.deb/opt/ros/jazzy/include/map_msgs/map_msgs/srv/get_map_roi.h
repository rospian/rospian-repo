// generated from rosidl_generator_c/resource/idl.h.em
// with input from map_msgs:srv/GetMapROI.idl
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__SRV__GET_MAP_ROI_H_
#define MAP_MSGS__SRV__GET_MAP_ROI_H_

#include "map_msgs/srv/detail/get_map_roi__struct.h"
#include "map_msgs/srv/detail/get_map_roi__functions.h"
#include "map_msgs/srv/detail/get_map_roi__type_support.h"

#endif  // MAP_MSGS__SRV__GET_MAP_ROI_H_
