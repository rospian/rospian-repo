// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MAP_MSGS__SRV__SET_MAP_PROJECTIONS_HPP_
#define MAP_MSGS__SRV__SET_MAP_PROJECTIONS_HPP_

#include "map_msgs/srv/detail/set_map_projections__struct.hpp"
#include "map_msgs/srv/detail/set_map_projections__builder.hpp"
#include "map_msgs/srv/detail/set_map_projections__traits.hpp"
#include "map_msgs/srv/detail/set_map_projections__type_support.hpp"

#endif  // MAP_MSGS__SRV__SET_MAP_PROJECTIONS_HPP_
