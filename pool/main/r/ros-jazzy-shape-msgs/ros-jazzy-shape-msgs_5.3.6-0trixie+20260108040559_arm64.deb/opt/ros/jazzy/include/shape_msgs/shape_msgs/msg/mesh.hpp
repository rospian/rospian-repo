// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__MESH_HPP_
#define SHAPE_MSGS__MSG__MESH_HPP_

#include "shape_msgs/msg/detail/mesh__struct.hpp"
#include "shape_msgs/msg/detail/mesh__builder.hpp"
#include "shape_msgs/msg/detail/mesh__traits.hpp"
#include "shape_msgs/msg/detail/mesh__type_support.hpp"

#endif  // SHAPE_MSGS__MSG__MESH_HPP_
