// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__MESH_TRIANGLE_HPP_
#define SHAPE_MSGS__MSG__MESH_TRIANGLE_HPP_

#include "shape_msgs/msg/detail/mesh_triangle__struct.hpp"
#include "shape_msgs/msg/detail/mesh_triangle__builder.hpp"
#include "shape_msgs/msg/detail/mesh_triangle__traits.hpp"
#include "shape_msgs/msg/detail/mesh_triangle__type_support.hpp"

#endif  // SHAPE_MSGS__MSG__MESH_TRIANGLE_HPP_
