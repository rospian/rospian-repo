// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SHAPE_MSGS__MSG__PLANE_HPP_
#define SHAPE_MSGS__MSG__PLANE_HPP_

#include "shape_msgs/msg/detail/plane__struct.hpp"
#include "shape_msgs/msg/detail/plane__builder.hpp"
#include "shape_msgs/msg/detail/plane__traits.hpp"
#include "shape_msgs/msg/detail/plane__type_support.hpp"

#endif  // SHAPE_MSGS__MSG__PLANE_HPP_
