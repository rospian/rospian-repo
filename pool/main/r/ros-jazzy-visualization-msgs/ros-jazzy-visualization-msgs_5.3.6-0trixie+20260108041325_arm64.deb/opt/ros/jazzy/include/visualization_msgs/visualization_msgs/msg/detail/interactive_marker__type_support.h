// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from visualization_msgs:msg/InteractiveMarker.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "visualization_msgs/msg/interactive_marker.h"


#ifndef VISUALIZATION_MSGS__MSG__DETAIL__INTERACTIVE_MARKER__TYPE_SUPPORT_H_
#define VISUALIZATION_MSGS__MSG__DETAIL__INTERACTIVE_MARKER__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "visualization_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_visualization_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  visualization_msgs,
  msg,
  InteractiveMarker
)(void);

#ifdef __cplusplus
}
#endif

#endif  // VISUALIZATION_MSGS__MSG__DETAIL__INTERACTIVE_MARKER__TYPE_SUPPORT_H_
