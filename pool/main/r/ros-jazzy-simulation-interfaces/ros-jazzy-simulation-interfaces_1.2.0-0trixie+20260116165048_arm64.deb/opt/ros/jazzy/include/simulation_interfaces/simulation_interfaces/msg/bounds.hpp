// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__BOUNDS_HPP_
#define SIMULATION_INTERFACES__MSG__BOUNDS_HPP_

#include "simulation_interfaces/msg/detail/bounds__struct.hpp"
#include "simulation_interfaces/msg/detail/bounds__builder.hpp"
#include "simulation_interfaces/msg/detail/bounds__traits.hpp"
#include "simulation_interfaces/msg/detail/bounds__type_support.hpp"

#endif  // SIMULATION_INTERFACES__MSG__BOUNDS_HPP_
