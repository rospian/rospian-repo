// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/NamedPose.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__NAMED_POSE_H_
#define SIMULATION_INTERFACES__MSG__NAMED_POSE_H_

#include "simulation_interfaces/msg/detail/named_pose__struct.h"
#include "simulation_interfaces/msg/detail/named_pose__functions.h"
#include "simulation_interfaces/msg/detail/named_pose__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__NAMED_POSE_H_
