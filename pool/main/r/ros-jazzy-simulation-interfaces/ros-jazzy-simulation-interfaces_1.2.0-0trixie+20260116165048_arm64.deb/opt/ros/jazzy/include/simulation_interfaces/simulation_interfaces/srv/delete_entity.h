// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:srv/DeleteEntity.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__SRV__DELETE_ENTITY_H_
#define SIMULATION_INTERFACES__SRV__DELETE_ENTITY_H_

#include "simulation_interfaces/srv/detail/delete_entity__struct.h"
#include "simulation_interfaces/srv/detail/delete_entity__functions.h"
#include "simulation_interfaces/srv/detail/delete_entity__type_support.h"

#endif  // SIMULATION_INTERFACES__SRV__DELETE_ENTITY_H_
