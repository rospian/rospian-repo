// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/Bounds.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__BOUNDS_H_
#define SIMULATION_INTERFACES__MSG__BOUNDS_H_

#include "simulation_interfaces/msg/detail/bounds__struct.h"
#include "simulation_interfaces/msg/detail/bounds__functions.h"
#include "simulation_interfaces/msg/detail/bounds__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__BOUNDS_H_
