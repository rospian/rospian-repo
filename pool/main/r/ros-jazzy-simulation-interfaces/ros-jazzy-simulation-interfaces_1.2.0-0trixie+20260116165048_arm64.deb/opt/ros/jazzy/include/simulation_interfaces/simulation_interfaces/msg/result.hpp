// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__RESULT_HPP_
#define SIMULATION_INTERFACES__MSG__RESULT_HPP_

#include "simulation_interfaces/msg/detail/result__struct.hpp"
#include "simulation_interfaces/msg/detail/result__builder.hpp"
#include "simulation_interfaces/msg/detail/result__traits.hpp"
#include "simulation_interfaces/msg/detail/result__type_support.hpp"

#endif  // SIMULATION_INTERFACES__MSG__RESULT_HPP_
