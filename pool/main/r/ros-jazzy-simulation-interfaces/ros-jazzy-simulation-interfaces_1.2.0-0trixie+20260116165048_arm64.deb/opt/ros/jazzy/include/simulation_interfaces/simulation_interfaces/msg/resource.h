// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/Resource.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__RESOURCE_H_
#define SIMULATION_INTERFACES__MSG__RESOURCE_H_

#include "simulation_interfaces/msg/detail/resource__struct.h"
#include "simulation_interfaces/msg/detail/resource__functions.h"
#include "simulation_interfaces/msg/detail/resource__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__RESOURCE_H_
