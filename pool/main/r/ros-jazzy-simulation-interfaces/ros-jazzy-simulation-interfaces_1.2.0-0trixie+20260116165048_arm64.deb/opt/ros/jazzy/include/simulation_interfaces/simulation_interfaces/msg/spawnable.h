// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/Spawnable.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__SPAWNABLE_H_
#define SIMULATION_INTERFACES__MSG__SPAWNABLE_H_

#include "simulation_interfaces/msg/detail/spawnable__struct.h"
#include "simulation_interfaces/msg/detail/spawnable__functions.h"
#include "simulation_interfaces/msg/detail/spawnable__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__SPAWNABLE_H_
