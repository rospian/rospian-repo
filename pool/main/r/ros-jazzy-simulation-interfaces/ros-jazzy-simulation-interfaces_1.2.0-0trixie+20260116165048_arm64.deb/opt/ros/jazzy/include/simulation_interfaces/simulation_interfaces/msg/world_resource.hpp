// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__WORLD_RESOURCE_HPP_
#define SIMULATION_INTERFACES__MSG__WORLD_RESOURCE_HPP_

#include "simulation_interfaces/msg/detail/world_resource__struct.hpp"
#include "simulation_interfaces/msg/detail/world_resource__builder.hpp"
#include "simulation_interfaces/msg/detail/world_resource__traits.hpp"
#include "simulation_interfaces/msg/detail/world_resource__type_support.hpp"

#endif  // SIMULATION_INTERFACES__MSG__WORLD_RESOURCE_HPP_
