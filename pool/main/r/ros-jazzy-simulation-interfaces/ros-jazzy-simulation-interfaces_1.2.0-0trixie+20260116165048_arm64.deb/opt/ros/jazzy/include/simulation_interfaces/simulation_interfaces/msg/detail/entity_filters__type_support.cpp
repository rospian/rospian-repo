// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from simulation_interfaces:msg/EntityFilters.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "simulation_interfaces/msg/detail/entity_filters__functions.h"
#include "simulation_interfaces/msg/detail/entity_filters__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace simulation_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void EntityFilters_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) simulation_interfaces::msg::EntityFilters(_init);
}

void EntityFilters_fini_function(void * message_memory)
{
  auto typed_message = static_cast<simulation_interfaces::msg::EntityFilters *>(message_memory);
  typed_message->~EntityFilters();
}

size_t size_function__EntityFilters__categories(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<simulation_interfaces::msg::EntityCategory> *>(untyped_member);
  return member->size();
}

const void * get_const_function__EntityFilters__categories(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<simulation_interfaces::msg::EntityCategory> *>(untyped_member);
  return &member[index];
}

void * get_function__EntityFilters__categories(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<simulation_interfaces::msg::EntityCategory> *>(untyped_member);
  return &member[index];
}

void fetch_function__EntityFilters__categories(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const simulation_interfaces::msg::EntityCategory *>(
    get_const_function__EntityFilters__categories(untyped_member, index));
  auto & value = *reinterpret_cast<simulation_interfaces::msg::EntityCategory *>(untyped_value);
  value = item;
}

void assign_function__EntityFilters__categories(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<simulation_interfaces::msg::EntityCategory *>(
    get_function__EntityFilters__categories(untyped_member, index));
  const auto & value = *reinterpret_cast<const simulation_interfaces::msg::EntityCategory *>(untyped_value);
  item = value;
}

void resize_function__EntityFilters__categories(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<simulation_interfaces::msg::EntityCategory> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember EntityFilters_message_member_array[4] = {
  {
    "filter",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(simulation_interfaces::msg::EntityFilters, filter),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "categories",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<simulation_interfaces::msg::EntityCategory>(),  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(simulation_interfaces::msg::EntityFilters, categories),  // bytes offset in struct
    nullptr,  // default value
    size_function__EntityFilters__categories,  // size() function pointer
    get_const_function__EntityFilters__categories,  // get_const(index) function pointer
    get_function__EntityFilters__categories,  // get(index) function pointer
    fetch_function__EntityFilters__categories,  // fetch(index, &value) function pointer
    assign_function__EntityFilters__categories,  // assign(index, value) function pointer
    resize_function__EntityFilters__categories  // resize(index) function pointer
  },
  {
    "tags",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<simulation_interfaces::msg::TagsFilter>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(simulation_interfaces::msg::EntityFilters, tags),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "bounds",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<simulation_interfaces::msg::Bounds>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(simulation_interfaces::msg::EntityFilters, bounds),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers EntityFilters_message_members = {
  "simulation_interfaces::msg",  // message namespace
  "EntityFilters",  // message name
  4,  // number of fields
  sizeof(simulation_interfaces::msg::EntityFilters),
  false,  // has_any_key_member_
  EntityFilters_message_member_array,  // message members
  EntityFilters_init_function,  // function to initialize message memory (memory has to be allocated)
  EntityFilters_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t EntityFilters_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &EntityFilters_message_members,
  get_message_typesupport_handle_function,
  &simulation_interfaces__msg__EntityFilters__get_type_hash,
  &simulation_interfaces__msg__EntityFilters__get_type_description,
  &simulation_interfaces__msg__EntityFilters__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace simulation_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<simulation_interfaces::msg::EntityFilters>()
{
  return &::simulation_interfaces::msg::rosidl_typesupport_introspection_cpp::EntityFilters_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, simulation_interfaces, msg, EntityFilters)() {
  return &::simulation_interfaces::msg::rosidl_typesupport_introspection_cpp::EntityFilters_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
