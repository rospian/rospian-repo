// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from simulation_interfaces:action/SimulateSteps.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "simulation_interfaces/action/simulate_steps.h"


#ifndef SIMULATION_INTERFACES__ACTION__DETAIL__SIMULATE_STEPS__STRUCT_H_
#define SIMULATION_INTERFACES__ACTION__DETAIL__SIMULATE_STEPS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_Goal
{
  /// Action goal: step through the simulation loop this many times.
  uint64_t steps;
} simulation_interfaces__action__SimulateSteps_Goal;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_Goal.
typedef struct simulation_interfaces__action__SimulateSteps_Goal__Sequence
{
  simulation_interfaces__action__SimulateSteps_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_Goal__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
#include "simulation_interfaces/msg/detail/result__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_Result
{
  /// Calling with simulation unpaused will return OPERATION_FAILED and error message.
  simulation_interfaces__msg__Result result;
} simulation_interfaces__action__SimulateSteps_Result;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_Result.
typedef struct simulation_interfaces__action__SimulateSteps_Result__Sequence
{
  simulation_interfaces__action__SimulateSteps_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_Result__Sequence;

// Constants defined in the message

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_Feedback
{
  /// number of completed steps in this action so far.
  uint64_t completed_steps;
  /// number of steps remaining to be completed in this action.
  uint64_t remaining_steps;
} simulation_interfaces__action__SimulateSteps_Feedback;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_Feedback.
typedef struct simulation_interfaces__action__SimulateSteps_Feedback__Sequence
{
  simulation_interfaces__action__SimulateSteps_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_Feedback__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "simulation_interfaces/action/detail/simulate_steps__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  simulation_interfaces__action__SimulateSteps_Goal goal;
} simulation_interfaces__action__SimulateSteps_SendGoal_Request;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_SendGoal_Request.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Request__Sequence
{
  simulation_interfaces__action__SimulateSteps_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_SendGoal_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} simulation_interfaces__action__SimulateSteps_SendGoal_Response;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_SendGoal_Response.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Response__Sequence
{
  simulation_interfaces__action__SimulateSteps_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_SendGoal_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  simulation_interfaces__action__SimulateSteps_SendGoal_Event__request__MAX_SIZE = 1
};
// response
enum
{
  simulation_interfaces__action__SimulateSteps_SendGoal_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Event
{
  service_msgs__msg__ServiceEventInfo info;
  simulation_interfaces__action__SimulateSteps_SendGoal_Request__Sequence request;
  simulation_interfaces__action__SimulateSteps_SendGoal_Response__Sequence response;
} simulation_interfaces__action__SimulateSteps_SendGoal_Event;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_SendGoal_Event.
typedef struct simulation_interfaces__action__SimulateSteps_SendGoal_Event__Sequence
{
  simulation_interfaces__action__SimulateSteps_SendGoal_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_SendGoal_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} simulation_interfaces__action__SimulateSteps_GetResult_Request;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_GetResult_Request.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Request__Sequence
{
  simulation_interfaces__action__SimulateSteps_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_GetResult_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "simulation_interfaces/action/detail/simulate_steps__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Response
{
  int8_t status;
  simulation_interfaces__action__SimulateSteps_Result result;
} simulation_interfaces__action__SimulateSteps_GetResult_Response;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_GetResult_Response.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Response__Sequence
{
  simulation_interfaces__action__SimulateSteps_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_GetResult_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
// already included above
// #include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  simulation_interfaces__action__SimulateSteps_GetResult_Event__request__MAX_SIZE = 1
};
// response
enum
{
  simulation_interfaces__action__SimulateSteps_GetResult_Event__response__MAX_SIZE = 1
};

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Event
{
  service_msgs__msg__ServiceEventInfo info;
  simulation_interfaces__action__SimulateSteps_GetResult_Request__Sequence request;
  simulation_interfaces__action__SimulateSteps_GetResult_Response__Sequence response;
} simulation_interfaces__action__SimulateSteps_GetResult_Event;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_GetResult_Event.
typedef struct simulation_interfaces__action__SimulateSteps_GetResult_Event__Sequence
{
  simulation_interfaces__action__SimulateSteps_GetResult_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_GetResult_Event__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "simulation_interfaces/action/detail/simulate_steps__struct.h"

/// Struct defined in action/SimulateSteps in the package simulation_interfaces.
typedef struct simulation_interfaces__action__SimulateSteps_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  simulation_interfaces__action__SimulateSteps_Feedback feedback;
} simulation_interfaces__action__SimulateSteps_FeedbackMessage;

// Struct for a sequence of simulation_interfaces__action__SimulateSteps_FeedbackMessage.
typedef struct simulation_interfaces__action__SimulateSteps_FeedbackMessage__Sequence
{
  simulation_interfaces__action__SimulateSteps_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulation_interfaces__action__SimulateSteps_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SIMULATION_INTERFACES__ACTION__DETAIL__SIMULATE_STEPS__STRUCT_H_
