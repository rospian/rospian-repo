// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/EntityState.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__ENTITY_STATE_H_
#define SIMULATION_INTERFACES__MSG__ENTITY_STATE_H_

#include "simulation_interfaces/msg/detail/entity_state__struct.h"
#include "simulation_interfaces/msg/detail/entity_state__functions.h"
#include "simulation_interfaces/msg/detail/entity_state__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__ENTITY_STATE_H_
