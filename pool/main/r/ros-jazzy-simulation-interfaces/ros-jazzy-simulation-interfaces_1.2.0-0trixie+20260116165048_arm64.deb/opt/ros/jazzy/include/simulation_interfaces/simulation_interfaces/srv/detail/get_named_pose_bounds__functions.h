// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from simulation_interfaces:srv/GetNamedPoseBounds.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "simulation_interfaces/srv/get_named_pose_bounds.h"


#ifndef SIMULATION_INTERFACES__SRV__DETAIL__GET_NAMED_POSE_BOUNDS__FUNCTIONS_H_
#define SIMULATION_INTERFACES__SRV__DETAIL__GET_NAMED_POSE_BOUNDS__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/action_type_support_struct.h"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_runtime_c/service_type_support_struct.h"
#include "rosidl_runtime_c/type_description/type_description__struct.h"
#include "rosidl_runtime_c/type_description/type_source__struct.h"
#include "rosidl_runtime_c/type_hash.h"
#include "rosidl_runtime_c/visibility_control.h"
#include "simulation_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "simulation_interfaces/srv/detail/get_named_pose_bounds__struct.h"

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_type_hash_t *
simulation_interfaces__srv__GetNamedPoseBounds__get_type_hash(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeDescription *
simulation_interfaces__srv__GetNamedPoseBounds__get_type_description(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource *
simulation_interfaces__srv__GetNamedPoseBounds__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds__get_type_description_sources(
  const rosidl_service_type_support_t * type_support);

/// Initialize srv/GetNamedPoseBounds message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * simulation_interfaces__srv__GetNamedPoseBounds_Request
 * )) before or use
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__init(simulation_interfaces__srv__GetNamedPoseBounds_Request * msg);

/// Finalize srv/GetNamedPoseBounds message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Request__fini(simulation_interfaces__srv__GetNamedPoseBounds_Request * msg);

/// Create srv/GetNamedPoseBounds message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Request *
simulation_interfaces__srv__GetNamedPoseBounds_Request__create(void);

/// Destroy srv/GetNamedPoseBounds message.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Request__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Request * msg);

/// Check for srv/GetNamedPoseBounds message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Request * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Request * rhs);

/// Copy a srv/GetNamedPoseBounds message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Request * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Request * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_type_hash_t *
simulation_interfaces__srv__GetNamedPoseBounds_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeDescription *
simulation_interfaces__srv__GetNamedPoseBounds_Request__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource *
simulation_interfaces__srv__GetNamedPoseBounds_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the number of elements and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__init(simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * array, size_t size);

/// Finalize array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__fini(simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * array);

/// Create array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the array and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__create(size_t size);

/// Destroy array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * array);

/// Check for srv/GetNamedPoseBounds message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * rhs);

/// Copy an array of srv/GetNamedPoseBounds messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Request__Sequence * output);

/// Initialize srv/GetNamedPoseBounds message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * simulation_interfaces__srv__GetNamedPoseBounds_Response
 * )) before or use
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__init(simulation_interfaces__srv__GetNamedPoseBounds_Response * msg);

/// Finalize srv/GetNamedPoseBounds message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Response__fini(simulation_interfaces__srv__GetNamedPoseBounds_Response * msg);

/// Create srv/GetNamedPoseBounds message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Response *
simulation_interfaces__srv__GetNamedPoseBounds_Response__create(void);

/// Destroy srv/GetNamedPoseBounds message.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Response__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Response * msg);

/// Check for srv/GetNamedPoseBounds message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Response * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Response * rhs);

/// Copy a srv/GetNamedPoseBounds message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Response * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Response * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_type_hash_t *
simulation_interfaces__srv__GetNamedPoseBounds_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeDescription *
simulation_interfaces__srv__GetNamedPoseBounds_Response__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource *
simulation_interfaces__srv__GetNamedPoseBounds_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the number of elements and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__init(simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * array, size_t size);

/// Finalize array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__fini(simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * array);

/// Create array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the array and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__create(size_t size);

/// Destroy array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * array);

/// Check for srv/GetNamedPoseBounds message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * rhs);

/// Copy an array of srv/GetNamedPoseBounds messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Response__Sequence * output);

/// Initialize srv/GetNamedPoseBounds message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * simulation_interfaces__srv__GetNamedPoseBounds_Event
 * )) before or use
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__init(simulation_interfaces__srv__GetNamedPoseBounds_Event * msg);

/// Finalize srv/GetNamedPoseBounds message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Event__fini(simulation_interfaces__srv__GetNamedPoseBounds_Event * msg);

/// Create srv/GetNamedPoseBounds message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Event *
simulation_interfaces__srv__GetNamedPoseBounds_Event__create(void);

/// Destroy srv/GetNamedPoseBounds message.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Event__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Event * msg);

/// Check for srv/GetNamedPoseBounds message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Event * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Event * rhs);

/// Copy a srv/GetNamedPoseBounds message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Event * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Event * output);

/// Retrieve pointer to the hash of the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_type_hash_t *
simulation_interfaces__srv__GetNamedPoseBounds_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeDescription *
simulation_interfaces__srv__GetNamedPoseBounds_Event__get_type_description(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the single raw source text that defined this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource *
simulation_interfaces__srv__GetNamedPoseBounds_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support);

/// Retrieve pointer to the recursive raw sources that defined the description of this type.
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
const rosidl_runtime_c__type_description__TypeSource__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support);

/// Initialize array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the number of elements and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__init(simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * array, size_t size);

/// Finalize array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__fini(simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * array);

/// Create array of srv/GetNamedPoseBounds messages.
/**
 * It allocates the memory for the array and calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence *
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__create(size_t size);

/// Destroy array of srv/GetNamedPoseBounds messages.
/**
 * It calls
 * simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
void
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__destroy(simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * array);

/// Check for srv/GetNamedPoseBounds message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__are_equal(const simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * lhs, const simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * rhs);

/// Copy an array of srv/GetNamedPoseBounds messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_simulation_interfaces
bool
simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence__copy(
  const simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * input,
  simulation_interfaces__srv__GetNamedPoseBounds_Event__Sequence * output);
#ifdef __cplusplus
}
#endif

#endif  // SIMULATION_INTERFACES__SRV__DETAIL__GET_NAMED_POSE_BOUNDS__FUNCTIONS_H_
