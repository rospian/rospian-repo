// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/SimulatorFeatures.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__SIMULATOR_FEATURES_H_
#define SIMULATION_INTERFACES__MSG__SIMULATOR_FEATURES_H_

#include "simulation_interfaces/msg/detail/simulator_features__struct.h"
#include "simulation_interfaces/msg/detail/simulator_features__functions.h"
#include "simulation_interfaces/msg/detail/simulator_features__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__SIMULATOR_FEATURES_H_
