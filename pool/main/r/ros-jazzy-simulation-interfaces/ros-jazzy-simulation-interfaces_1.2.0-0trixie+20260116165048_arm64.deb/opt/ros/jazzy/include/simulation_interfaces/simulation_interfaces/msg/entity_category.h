// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulation_interfaces:msg/EntityCategory.idl
// generated code does not contain a copyright notice

#ifndef SIMULATION_INTERFACES__MSG__ENTITY_CATEGORY_H_
#define SIMULATION_INTERFACES__MSG__ENTITY_CATEGORY_H_

#include "simulation_interfaces/msg/detail/entity_category__struct.h"
#include "simulation_interfaces/msg/detail/entity_category__functions.h"
#include "simulation_interfaces/msg/detail/entity_category__type_support.h"

#endif  // SIMULATION_INTERFACES__MSG__ENTITY_CATEGORY_H_
