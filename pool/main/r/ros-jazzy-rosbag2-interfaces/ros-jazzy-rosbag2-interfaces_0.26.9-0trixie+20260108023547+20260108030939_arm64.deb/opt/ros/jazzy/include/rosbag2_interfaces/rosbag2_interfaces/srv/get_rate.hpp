// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__GET_RATE_HPP_
#define ROSBAG2_INTERFACES__SRV__GET_RATE_HPP_

#include "rosbag2_interfaces/srv/detail/get_rate__struct.hpp"
#include "rosbag2_interfaces/srv/detail/get_rate__builder.hpp"
#include "rosbag2_interfaces/srv/detail/get_rate__traits.hpp"
#include "rosbag2_interfaces/srv/detail/get_rate__type_support.hpp"

#endif  // ROSBAG2_INTERFACES__SRV__GET_RATE_HPP_
