// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_interfaces:srv/Stop.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__STOP_H_
#define ROSBAG2_INTERFACES__SRV__STOP_H_

#include "rosbag2_interfaces/srv/detail/stop__struct.h"
#include "rosbag2_interfaces/srv/detail/stop__functions.h"
#include "rosbag2_interfaces/srv/detail/stop__type_support.h"

#endif  // ROSBAG2_INTERFACES__SRV__STOP_H_
