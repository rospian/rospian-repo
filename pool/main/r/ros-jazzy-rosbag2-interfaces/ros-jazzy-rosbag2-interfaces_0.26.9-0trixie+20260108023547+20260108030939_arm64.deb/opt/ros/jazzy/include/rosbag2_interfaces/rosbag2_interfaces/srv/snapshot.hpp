// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__SNAPSHOT_HPP_
#define ROSBAG2_INTERFACES__SRV__SNAPSHOT_HPP_

#include "rosbag2_interfaces/srv/detail/snapshot__struct.hpp"
#include "rosbag2_interfaces/srv/detail/snapshot__builder.hpp"
#include "rosbag2_interfaces/srv/detail/snapshot__traits.hpp"
#include "rosbag2_interfaces/srv/detail/snapshot__type_support.hpp"

#endif  // ROSBAG2_INTERFACES__SRV__SNAPSHOT_HPP_
