// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_interfaces:srv/Pause.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__PAUSE_H_
#define ROSBAG2_INTERFACES__SRV__PAUSE_H_

#include "rosbag2_interfaces/srv/detail/pause__struct.h"
#include "rosbag2_interfaces/srv/detail/pause__functions.h"
#include "rosbag2_interfaces/srv/detail/pause__type_support.h"

#endif  // ROSBAG2_INTERFACES__SRV__PAUSE_H_
