// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__STOP_HPP_
#define ROSBAG2_INTERFACES__SRV__STOP_HPP_

#include "rosbag2_interfaces/srv/detail/stop__struct.hpp"
#include "rosbag2_interfaces/srv/detail/stop__builder.hpp"
#include "rosbag2_interfaces/srv/detail/stop__traits.hpp"
#include "rosbag2_interfaces/srv/detail/stop__type_support.hpp"

#endif  // ROSBAG2_INTERFACES__SRV__STOP_HPP_
