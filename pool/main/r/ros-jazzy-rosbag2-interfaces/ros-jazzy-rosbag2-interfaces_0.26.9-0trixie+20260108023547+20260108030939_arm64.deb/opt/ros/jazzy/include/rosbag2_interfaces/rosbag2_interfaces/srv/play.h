// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_interfaces:srv/Play.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__PLAY_H_
#define ROSBAG2_INTERFACES__SRV__PLAY_H_

#include "rosbag2_interfaces/srv/detail/play__struct.h"
#include "rosbag2_interfaces/srv/detail/play__functions.h"
#include "rosbag2_interfaces/srv/detail/play__type_support.h"

#endif  // ROSBAG2_INTERFACES__SRV__PLAY_H_
