// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_INTERFACES__SRV__PLAY_NEXT_HPP_
#define ROSBAG2_INTERFACES__SRV__PLAY_NEXT_HPP_

#include "rosbag2_interfaces/srv/detail/play_next__struct.hpp"
#include "rosbag2_interfaces/srv/detail/play_next__builder.hpp"
#include "rosbag2_interfaces/srv/detail/play_next__traits.hpp"
#include "rosbag2_interfaces/srv/detail/play_next__type_support.hpp"

#endif  // ROSBAG2_INTERFACES__SRV__PLAY_NEXT_HPP_
