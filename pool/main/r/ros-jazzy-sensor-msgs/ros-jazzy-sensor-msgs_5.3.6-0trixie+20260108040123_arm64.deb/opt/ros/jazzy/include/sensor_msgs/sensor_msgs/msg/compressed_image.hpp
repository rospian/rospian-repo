// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__COMPRESSED_IMAGE_HPP_
#define SENSOR_MSGS__MSG__COMPRESSED_IMAGE_HPP_

#include "sensor_msgs/msg/detail/compressed_image__struct.hpp"
#include "sensor_msgs/msg/detail/compressed_image__builder.hpp"
#include "sensor_msgs/msg/detail/compressed_image__traits.hpp"
#include "sensor_msgs/msg/detail/compressed_image__type_support.hpp"

#endif  // SENSOR_MSGS__MSG__COMPRESSED_IMAGE_HPP_
