// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/JoyFeedback.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__JOY_FEEDBACK_H_
#define SENSOR_MSGS__MSG__JOY_FEEDBACK_H_

#include "sensor_msgs/msg/detail/joy_feedback__struct.h"
#include "sensor_msgs/msg/detail/joy_feedback__functions.h"
#include "sensor_msgs/msg/detail/joy_feedback__type_support.h"

#endif  // SENSOR_MSGS__MSG__JOY_FEEDBACK_H_
