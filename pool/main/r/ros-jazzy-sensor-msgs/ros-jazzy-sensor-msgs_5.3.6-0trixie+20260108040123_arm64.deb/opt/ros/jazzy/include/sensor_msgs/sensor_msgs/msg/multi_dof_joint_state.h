// generated from rosidl_generator_c/resource/idl.h.em
// with input from sensor_msgs:msg/MultiDOFJointState.idl
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__MULTI_DOF_JOINT_STATE_H_
#define SENSOR_MSGS__MSG__MULTI_DOF_JOINT_STATE_H_

#include "sensor_msgs/msg/detail/multi_dof_joint_state__struct.h"
#include "sensor_msgs/msg/detail/multi_dof_joint_state__functions.h"
#include "sensor_msgs/msg/detail/multi_dof_joint_state__type_support.h"

#endif  // SENSOR_MSGS__MSG__MULTI_DOF_JOINT_STATE_H_
