// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SENSOR_MSGS__MSG__ILLUMINANCE_HPP_
#define SENSOR_MSGS__MSG__ILLUMINANCE_HPP_

#include "sensor_msgs/msg/detail/illuminance__struct.hpp"
#include "sensor_msgs/msg/detail/illuminance__builder.hpp"
#include "sensor_msgs/msg/detail/illuminance__traits.hpp"
#include "sensor_msgs/msg/detail/illuminance__type_support.hpp"

#endif  // SENSOR_MSGS__MSG__ILLUMINANCE_HPP_
