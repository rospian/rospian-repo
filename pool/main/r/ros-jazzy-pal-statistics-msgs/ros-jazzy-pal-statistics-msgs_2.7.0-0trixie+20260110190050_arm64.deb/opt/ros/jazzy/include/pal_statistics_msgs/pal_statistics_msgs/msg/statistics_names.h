// generated from rosidl_generator_c/resource/idl.h.em
// with input from pal_statistics_msgs:msg/StatisticsNames.idl
// generated code does not contain a copyright notice

#ifndef PAL_STATISTICS_MSGS__MSG__STATISTICS_NAMES_H_
#define PAL_STATISTICS_MSGS__MSG__STATISTICS_NAMES_H_

#include "pal_statistics_msgs/msg/detail/statistics_names__struct.h"
#include "pal_statistics_msgs/msg/detail/statistics_names__functions.h"
#include "pal_statistics_msgs/msg/detail/statistics_names__type_support.h"

#endif  // PAL_STATISTICS_MSGS__MSG__STATISTICS_NAMES_H_
