// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PAL_STATISTICS_MSGS__MSG__STATISTICS_HPP_
#define PAL_STATISTICS_MSGS__MSG__STATISTICS_HPP_

#include "pal_statistics_msgs/msg/detail/statistics__struct.hpp"
#include "pal_statistics_msgs/msg/detail/statistics__builder.hpp"
#include "pal_statistics_msgs/msg/detail/statistics__traits.hpp"
#include "pal_statistics_msgs/msg/detail/statistics__type_support.hpp"

#endif  // PAL_STATISTICS_MSGS__MSG__STATISTICS_HPP_
