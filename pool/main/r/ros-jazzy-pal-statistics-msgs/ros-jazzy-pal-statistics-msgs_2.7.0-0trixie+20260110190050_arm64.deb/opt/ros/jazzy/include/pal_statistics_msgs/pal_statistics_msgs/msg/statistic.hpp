// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PAL_STATISTICS_MSGS__MSG__STATISTIC_HPP_
#define PAL_STATISTICS_MSGS__MSG__STATISTIC_HPP_

#include "pal_statistics_msgs/msg/detail/statistic__struct.hpp"
#include "pal_statistics_msgs/msg/detail/statistic__builder.hpp"
#include "pal_statistics_msgs/msg/detail/statistic__traits.hpp"
#include "pal_statistics_msgs/msg/detail/statistic__type_support.hpp"

#endif  // PAL_STATISTICS_MSGS__MSG__STATISTIC_HPP_
