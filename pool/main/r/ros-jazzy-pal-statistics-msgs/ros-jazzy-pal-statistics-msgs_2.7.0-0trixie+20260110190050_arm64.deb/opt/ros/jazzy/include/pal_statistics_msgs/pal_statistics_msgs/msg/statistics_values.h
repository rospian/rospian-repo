// generated from rosidl_generator_c/resource/idl.h.em
// with input from pal_statistics_msgs:msg/StatisticsValues.idl
// generated code does not contain a copyright notice

#ifndef PAL_STATISTICS_MSGS__MSG__STATISTICS_VALUES_H_
#define PAL_STATISTICS_MSGS__MSG__STATISTICS_VALUES_H_

#include "pal_statistics_msgs/msg/detail/statistics_values__struct.h"
#include "pal_statistics_msgs/msg/detail/statistics_values__functions.h"
#include "pal_statistics_msgs/msg/detail/statistics_values__type_support.h"

#endif  // PAL_STATISTICS_MSGS__MSG__STATISTICS_VALUES_H_
