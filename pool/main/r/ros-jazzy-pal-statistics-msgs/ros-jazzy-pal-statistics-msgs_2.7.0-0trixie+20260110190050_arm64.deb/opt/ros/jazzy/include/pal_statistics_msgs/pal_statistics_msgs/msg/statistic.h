// generated from rosidl_generator_c/resource/idl.h.em
// with input from pal_statistics_msgs:msg/Statistic.idl
// generated code does not contain a copyright notice

#ifndef PAL_STATISTICS_MSGS__MSG__STATISTIC_H_
#define PAL_STATISTICS_MSGS__MSG__STATISTIC_H_

#include "pal_statistics_msgs/msg/detail/statistic__struct.h"
#include "pal_statistics_msgs/msg/detail/statistic__functions.h"
#include "pal_statistics_msgs/msg/detail/statistic__type_support.h"

#endif  // PAL_STATISTICS_MSGS__MSG__STATISTIC_H_
