// generated from rosidl_generator_c/resource/idl.h.em
// with input from nav_msgs:msg/Goals.idl
// generated code does not contain a copyright notice

#ifndef NAV_MSGS__MSG__GOALS_H_
#define NAV_MSGS__MSG__GOALS_H_

#include "nav_msgs/msg/detail/goals__struct.h"
#include "nav_msgs/msg/detail/goals__functions.h"
#include "nav_msgs/msg/detail/goals__type_support.h"

#endif  // NAV_MSGS__MSG__GOALS_H_
