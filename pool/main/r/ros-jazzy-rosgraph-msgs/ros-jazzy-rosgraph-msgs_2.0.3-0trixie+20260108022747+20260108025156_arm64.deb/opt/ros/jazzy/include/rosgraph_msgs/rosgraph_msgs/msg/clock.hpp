// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSGRAPH_MSGS__MSG__CLOCK_HPP_
#define ROSGRAPH_MSGS__MSG__CLOCK_HPP_

#include "rosgraph_msgs/msg/detail/clock__struct.hpp"
#include "rosgraph_msgs/msg/detail/clock__builder.hpp"
#include "rosgraph_msgs/msg/detail/clock__traits.hpp"
#include "rosgraph_msgs/msg/detail/clock__type_support.hpp"

#endif  // ROSGRAPH_MSGS__MSG__CLOCK_HPP_
