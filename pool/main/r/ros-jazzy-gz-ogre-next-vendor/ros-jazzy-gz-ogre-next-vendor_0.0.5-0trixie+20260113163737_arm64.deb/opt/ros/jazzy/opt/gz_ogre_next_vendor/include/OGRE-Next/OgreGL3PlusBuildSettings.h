#ifndef OGREGL3PLUS_Custom_Config_H
#define OGREGL3PLUS_Custom_Config_H

// CMake auto-generated configuration options

#define OGRE_GLSUPPORT_USE_GLX
/* #undef OGRE_GLSUPPORT_USE_WGL */
/* #undef OGRE_GLSUPPORT_USE_COCOA */
#define OGRE_GLSUPPORT_USE_EGL_HEADLESS

#endif
