#ifndef OGREVulkan_Custom_Config_H
#define OGREVulkan_Custom_Config_H

// CMake auto-generated configuration options

#define OGRE_VULKAN_WINDOW_NULL
/* #undef OGRE_VULKAN_WINDOW_WIN32 */
#define OGRE_VULKAN_WINDOW_XCB
/* #undef OGRE_VULKAN_WINDOW_ANDROID */

#endif
