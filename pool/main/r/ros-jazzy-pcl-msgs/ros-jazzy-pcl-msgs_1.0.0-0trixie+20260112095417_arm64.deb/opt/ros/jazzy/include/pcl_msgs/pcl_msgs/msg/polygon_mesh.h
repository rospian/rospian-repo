// generated from rosidl_generator_c/resource/idl.h.em
// with input from pcl_msgs:msg/PolygonMesh.idl
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__POLYGON_MESH_H_
#define PCL_MSGS__MSG__POLYGON_MESH_H_

#include "pcl_msgs/msg/detail/polygon_mesh__struct.h"
#include "pcl_msgs/msg/detail/polygon_mesh__functions.h"
#include "pcl_msgs/msg/detail/polygon_mesh__type_support.h"

#endif  // PCL_MSGS__MSG__POLYGON_MESH_H_
