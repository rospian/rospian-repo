// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__POINT_INDICES_HPP_
#define PCL_MSGS__MSG__POINT_INDICES_HPP_

#include "pcl_msgs/msg/detail/point_indices__struct.hpp"
#include "pcl_msgs/msg/detail/point_indices__builder.hpp"
#include "pcl_msgs/msg/detail/point_indices__traits.hpp"
#include "pcl_msgs/msg/detail/point_indices__type_support.hpp"

#endif  // PCL_MSGS__MSG__POINT_INDICES_HPP_
