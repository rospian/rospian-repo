// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PCL_MSGS__MSG__VERTICES_HPP_
#define PCL_MSGS__MSG__VERTICES_HPP_

#include "pcl_msgs/msg/detail/vertices__struct.hpp"
#include "pcl_msgs/msg/detail/vertices__builder.hpp"
#include "pcl_msgs/msg/detail/vertices__traits.hpp"
#include "pcl_msgs/msg/detail/vertices__type_support.hpp"

#endif  // PCL_MSGS__MSG__VERTICES_HPP_
