// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from pcl_msgs:msg/PolygonMesh.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "pcl_msgs/msg/polygon_mesh.h"


#ifndef PCL_MSGS__MSG__DETAIL__POLYGON_MESH__TYPE_SUPPORT_H_
#define PCL_MSGS__MSG__DETAIL__POLYGON_MESH__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "pcl_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_pcl_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  pcl_msgs,
  msg,
  PolygonMesh
)(void);

#ifdef __cplusplus
}
#endif

#endif  // PCL_MSGS__MSG__DETAIL__POLYGON_MESH__TYPE_SUPPORT_H_
