// generated from rosidl_generator_c/resource/idl.h.em
// with input from theora_image_transport:msg/Packet.idl
// generated code does not contain a copyright notice

#ifndef THEORA_IMAGE_TRANSPORT__MSG__PACKET_H_
#define THEORA_IMAGE_TRANSPORT__MSG__PACKET_H_

#include "theora_image_transport/msg/detail/packet__struct.h"
#include "theora_image_transport/msg/detail/packet__functions.h"
#include "theora_image_transport/msg/detail/packet__type_support.h"

#endif  // THEORA_IMAGE_TRANSPORT__MSG__PACKET_H_
