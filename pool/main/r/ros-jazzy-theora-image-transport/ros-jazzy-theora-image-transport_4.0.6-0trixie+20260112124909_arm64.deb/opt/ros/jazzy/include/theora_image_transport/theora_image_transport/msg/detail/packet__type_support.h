// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from theora_image_transport:msg/Packet.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "theora_image_transport/msg/packet.h"


#ifndef THEORA_IMAGE_TRANSPORT__MSG__DETAIL__PACKET__TYPE_SUPPORT_H_
#define THEORA_IMAGE_TRANSPORT__MSG__DETAIL__PACKET__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "theora_image_transport/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_theora_image_transport
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  theora_image_transport,
  msg,
  Packet
)(void);

#ifdef __cplusplus
}
#endif

#endif  // THEORA_IMAGE_TRANSPORT__MSG__DETAIL__PACKET__TYPE_SUPPORT_H_
