// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/Float32Array.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__FLOAT32_ARRAY_H_
#define ROS_GZ_INTERFACES__MSG__FLOAT32_ARRAY_H_

#include "ros_gz_interfaces/msg/detail/float32_array__struct.h"
#include "ros_gz_interfaces/msg/detail/float32_array__functions.h"
#include "ros_gz_interfaces/msg/detail/float32_array__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__FLOAT32_ARRAY_H_
