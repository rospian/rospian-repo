// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/Entity.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__ENTITY_H_
#define ROS_GZ_INTERFACES__MSG__ENTITY_H_

#include "ros_gz_interfaces/msg/detail/entity__struct.h"
#include "ros_gz_interfaces/msg/detail/entity__functions.h"
#include "ros_gz_interfaces/msg/detail/entity__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__ENTITY_H_
