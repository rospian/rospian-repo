// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ros_gz_interfaces:srv/ControlWorld.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "ros_gz_interfaces/srv/control_world.hpp"


#ifndef ROS_GZ_INTERFACES__SRV__DETAIL__CONTROL_WORLD__BUILDER_HPP_
#define ROS_GZ_INTERFACES__SRV__DETAIL__CONTROL_WORLD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ros_gz_interfaces/srv/detail/control_world__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ros_gz_interfaces
{

namespace srv
{

namespace builder
{

class Init_ControlWorld_Request_world_control
{
public:
  Init_ControlWorld_Request_world_control()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::ros_gz_interfaces::srv::ControlWorld_Request world_control(::ros_gz_interfaces::srv::ControlWorld_Request::_world_control_type arg)
  {
    msg_.world_control = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros_gz_interfaces::srv::ControlWorld_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros_gz_interfaces::srv::ControlWorld_Request>()
{
  return ros_gz_interfaces::srv::builder::Init_ControlWorld_Request_world_control();
}

}  // namespace ros_gz_interfaces


namespace ros_gz_interfaces
{

namespace srv
{

namespace builder
{

class Init_ControlWorld_Response_success
{
public:
  Init_ControlWorld_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::ros_gz_interfaces::srv::ControlWorld_Response success(::ros_gz_interfaces::srv::ControlWorld_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros_gz_interfaces::srv::ControlWorld_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros_gz_interfaces::srv::ControlWorld_Response>()
{
  return ros_gz_interfaces::srv::builder::Init_ControlWorld_Response_success();
}

}  // namespace ros_gz_interfaces


namespace ros_gz_interfaces
{

namespace srv
{

namespace builder
{

class Init_ControlWorld_Event_response
{
public:
  explicit Init_ControlWorld_Event_response(::ros_gz_interfaces::srv::ControlWorld_Event & msg)
  : msg_(msg)
  {}
  ::ros_gz_interfaces::srv::ControlWorld_Event response(::ros_gz_interfaces::srv::ControlWorld_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ros_gz_interfaces::srv::ControlWorld_Event msg_;
};

class Init_ControlWorld_Event_request
{
public:
  explicit Init_ControlWorld_Event_request(::ros_gz_interfaces::srv::ControlWorld_Event & msg)
  : msg_(msg)
  {}
  Init_ControlWorld_Event_response request(::ros_gz_interfaces::srv::ControlWorld_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_ControlWorld_Event_response(msg_);
  }

private:
  ::ros_gz_interfaces::srv::ControlWorld_Event msg_;
};

class Init_ControlWorld_Event_info
{
public:
  Init_ControlWorld_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ControlWorld_Event_request info(::ros_gz_interfaces::srv::ControlWorld_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_ControlWorld_Event_request(msg_);
  }

private:
  ::ros_gz_interfaces::srv::ControlWorld_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ros_gz_interfaces::srv::ControlWorld_Event>()
{
  return ros_gz_interfaces::srv::builder::Init_ControlWorld_Event_info();
}

}  // namespace ros_gz_interfaces

#endif  // ROS_GZ_INTERFACES__SRV__DETAIL__CONTROL_WORLD__BUILDER_HPP_
