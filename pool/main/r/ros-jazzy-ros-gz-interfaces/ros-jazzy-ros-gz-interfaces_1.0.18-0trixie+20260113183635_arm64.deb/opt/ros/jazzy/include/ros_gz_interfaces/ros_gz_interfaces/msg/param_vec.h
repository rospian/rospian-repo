// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/ParamVec.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__PARAM_VEC_H_
#define ROS_GZ_INTERFACES__MSG__PARAM_VEC_H_

#include "ros_gz_interfaces/msg/detail/param_vec__struct.h"
#include "ros_gz_interfaces/msg/detail/param_vec__functions.h"
#include "ros_gz_interfaces/msg/detail/param_vec__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__PARAM_VEC_H_
