// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/StringVec.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__STRING_VEC_H_
#define ROS_GZ_INTERFACES__MSG__STRING_VEC_H_

#include "ros_gz_interfaces/msg/detail/string_vec__struct.h"
#include "ros_gz_interfaces/msg/detail/string_vec__functions.h"
#include "ros_gz_interfaces/msg/detail/string_vec__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__STRING_VEC_H_
