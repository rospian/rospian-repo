// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__MATERIAL_COLOR_HPP_
#define ROS_GZ_INTERFACES__MSG__MATERIAL_COLOR_HPP_

#include "ros_gz_interfaces/msg/detail/material_color__struct.hpp"
#include "ros_gz_interfaces/msg/detail/material_color__builder.hpp"
#include "ros_gz_interfaces/msg/detail/material_color__traits.hpp"
#include "ros_gz_interfaces/msg/detail/material_color__type_support.hpp"

#endif  // ROS_GZ_INTERFACES__MSG__MATERIAL_COLOR_HPP_
