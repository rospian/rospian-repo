// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/GuiCamera.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__GUI_CAMERA_H_
#define ROS_GZ_INTERFACES__MSG__GUI_CAMERA_H_

#include "ros_gz_interfaces/msg/detail/gui_camera__struct.h"
#include "ros_gz_interfaces/msg/detail/gui_camera__functions.h"
#include "ros_gz_interfaces/msg/detail/gui_camera__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__GUI_CAMERA_H_
