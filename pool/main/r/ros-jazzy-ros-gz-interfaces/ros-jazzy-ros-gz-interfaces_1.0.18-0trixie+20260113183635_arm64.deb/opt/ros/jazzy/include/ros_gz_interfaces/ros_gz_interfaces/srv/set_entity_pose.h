// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:srv/SetEntityPose.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__SRV__SET_ENTITY_POSE_H_
#define ROS_GZ_INTERFACES__SRV__SET_ENTITY_POSE_H_

#include "ros_gz_interfaces/srv/detail/set_entity_pose__struct.h"
#include "ros_gz_interfaces/srv/detail/set_entity_pose__functions.h"
#include "ros_gz_interfaces/srv/detail/set_entity_pose__type_support.h"

#endif  // ROS_GZ_INTERFACES__SRV__SET_ENTITY_POSE_H_
