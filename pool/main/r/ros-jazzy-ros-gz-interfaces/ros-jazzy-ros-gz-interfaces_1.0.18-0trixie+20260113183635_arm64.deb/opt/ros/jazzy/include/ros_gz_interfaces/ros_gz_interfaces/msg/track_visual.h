// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/TrackVisual.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__TRACK_VISUAL_H_
#define ROS_GZ_INTERFACES__MSG__TRACK_VISUAL_H_

#include "ros_gz_interfaces/msg/detail/track_visual__struct.h"
#include "ros_gz_interfaces/msg/detail/track_visual__functions.h"
#include "ros_gz_interfaces/msg/detail/track_visual__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__TRACK_VISUAL_H_
