// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/JointWrench.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__JOINT_WRENCH_H_
#define ROS_GZ_INTERFACES__MSG__JOINT_WRENCH_H_

#include "ros_gz_interfaces/msg/detail/joint_wrench__struct.h"
#include "ros_gz_interfaces/msg/detail/joint_wrench__functions.h"
#include "ros_gz_interfaces/msg/detail/joint_wrench__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__JOINT_WRENCH_H_
