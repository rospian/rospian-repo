// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros_gz_interfaces:msg/SensorNoise.idl
// generated code does not contain a copyright notice

#ifndef ROS_GZ_INTERFACES__MSG__SENSOR_NOISE_H_
#define ROS_GZ_INTERFACES__MSG__SENSOR_NOISE_H_

#include "ros_gz_interfaces/msg/detail/sensor_noise__struct.h"
#include "ros_gz_interfaces/msg/detail/sensor_noise__functions.h"
#include "ros_gz_interfaces/msg/detail/sensor_noise__type_support.h"

#endif  // ROS_GZ_INTERFACES__MSG__SENSOR_NOISE_H_
