// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__TYPE_SOURCE_HPP_
#define TYPE_DESCRIPTION_INTERFACES__MSG__TYPE_SOURCE_HPP_

#include "type_description_interfaces/msg/detail/type_source__struct.hpp"
#include "type_description_interfaces/msg/detail/type_source__builder.hpp"
#include "type_description_interfaces/msg/detail/type_source__traits.hpp"
#include "type_description_interfaces/msg/detail/type_source__type_support.hpp"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__TYPE_SOURCE_HPP_
