// generated from rosidl_generator_c/resource/idl.h.em
// with input from type_description_interfaces:msg/FieldType.idl
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_H_
#define TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_H_

#include "type_description_interfaces/msg/detail/field_type__struct.h"
#include "type_description_interfaces/msg/detail/field_type__functions.h"
#include "type_description_interfaces/msg/detail/field_type__type_support.h"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_H_
