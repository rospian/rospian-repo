// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_HPP_
#define TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_HPP_

#include "type_description_interfaces/msg/detail/key_value__struct.hpp"
#include "type_description_interfaces/msg/detail/key_value__builder.hpp"
#include "type_description_interfaces/msg/detail/key_value__traits.hpp"
#include "type_description_interfaces/msg/detail/key_value__type_support.hpp"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_HPP_
