// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_HPP_
#define TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_HPP_

#include "type_description_interfaces/msg/detail/field_type__struct.hpp"
#include "type_description_interfaces/msg/detail/field_type__builder.hpp"
#include "type_description_interfaces/msg/detail/field_type__traits.hpp"
#include "type_description_interfaces/msg/detail/field_type__type_support.hpp"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__FIELD_TYPE_HPP_
