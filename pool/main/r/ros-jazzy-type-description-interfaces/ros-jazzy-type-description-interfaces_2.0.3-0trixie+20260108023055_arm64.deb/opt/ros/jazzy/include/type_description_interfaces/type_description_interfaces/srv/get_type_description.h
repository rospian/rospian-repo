// generated from rosidl_generator_c/resource/idl.h.em
// with input from type_description_interfaces:srv/GetTypeDescription.idl
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__SRV__GET_TYPE_DESCRIPTION_H_
#define TYPE_DESCRIPTION_INTERFACES__SRV__GET_TYPE_DESCRIPTION_H_

#include "type_description_interfaces/srv/detail/get_type_description__struct.h"
#include "type_description_interfaces/srv/detail/get_type_description__functions.h"
#include "type_description_interfaces/srv/detail/get_type_description__type_support.h"

#endif  // TYPE_DESCRIPTION_INTERFACES__SRV__GET_TYPE_DESCRIPTION_H_
