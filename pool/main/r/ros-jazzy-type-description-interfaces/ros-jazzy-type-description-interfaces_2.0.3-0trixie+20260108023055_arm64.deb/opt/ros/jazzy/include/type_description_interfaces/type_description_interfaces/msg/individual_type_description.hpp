// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__INDIVIDUAL_TYPE_DESCRIPTION_HPP_
#define TYPE_DESCRIPTION_INTERFACES__MSG__INDIVIDUAL_TYPE_DESCRIPTION_HPP_

#include "type_description_interfaces/msg/detail/individual_type_description__struct.hpp"
#include "type_description_interfaces/msg/detail/individual_type_description__builder.hpp"
#include "type_description_interfaces/msg/detail/individual_type_description__traits.hpp"
#include "type_description_interfaces/msg/detail/individual_type_description__type_support.hpp"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__INDIVIDUAL_TYPE_DESCRIPTION_HPP_
