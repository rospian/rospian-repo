
#ifndef RSL_EXPORT_H
#define RSL_EXPORT_H

#ifdef RSL_STATIC_DEFINE
#  define RSL_EXPORT
#  define RSL_NO_EXPORT
#else
#  ifndef RSL_EXPORT
#    ifdef rsl_EXPORTS
        /* We are building this library */
#      define RSL_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define RSL_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef RSL_NO_EXPORT
#    define RSL_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef RSL_DEPRECATED
#  define RSL_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef RSL_DEPRECATED_EXPORT
#  define RSL_DEPRECATED_EXPORT RSL_EXPORT RSL_DEPRECATED
#endif

#ifndef RSL_DEPRECATED_NO_EXPORT
#  define RSL_DEPRECATED_NO_EXPORT RSL_NO_EXPORT RSL_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef RSL_NO_DEPRECATED
#    define RSL_NO_DEPRECATED
#  endif
#endif

#endif /* RSL_EXPORT_H */
