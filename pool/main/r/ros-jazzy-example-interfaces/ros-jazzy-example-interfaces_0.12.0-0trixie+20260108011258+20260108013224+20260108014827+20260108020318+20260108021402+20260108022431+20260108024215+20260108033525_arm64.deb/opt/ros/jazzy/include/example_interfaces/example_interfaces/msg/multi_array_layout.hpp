// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__MULTI_ARRAY_LAYOUT_HPP_
#define EXAMPLE_INTERFACES__MSG__MULTI_ARRAY_LAYOUT_HPP_

#include "example_interfaces/msg/detail/multi_array_layout__struct.hpp"
#include "example_interfaces/msg/detail/multi_array_layout__builder.hpp"
#include "example_interfaces/msg/detail/multi_array_layout__traits.hpp"
#include "example_interfaces/msg/detail/multi_array_layout__type_support.hpp"

#endif  // EXAMPLE_INTERFACES__MSG__MULTI_ARRAY_LAYOUT_HPP_
