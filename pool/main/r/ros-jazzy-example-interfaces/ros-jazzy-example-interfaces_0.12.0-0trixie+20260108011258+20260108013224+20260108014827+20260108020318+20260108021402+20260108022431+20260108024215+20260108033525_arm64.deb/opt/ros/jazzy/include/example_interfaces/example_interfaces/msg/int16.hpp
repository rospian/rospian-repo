// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__INT16_HPP_
#define EXAMPLE_INTERFACES__MSG__INT16_HPP_

#include "example_interfaces/msg/detail/int16__struct.hpp"
#include "example_interfaces/msg/detail/int16__builder.hpp"
#include "example_interfaces/msg/detail/int16__traits.hpp"
#include "example_interfaces/msg/detail/int16__type_support.hpp"

#endif  // EXAMPLE_INTERFACES__MSG__INT16_HPP_
