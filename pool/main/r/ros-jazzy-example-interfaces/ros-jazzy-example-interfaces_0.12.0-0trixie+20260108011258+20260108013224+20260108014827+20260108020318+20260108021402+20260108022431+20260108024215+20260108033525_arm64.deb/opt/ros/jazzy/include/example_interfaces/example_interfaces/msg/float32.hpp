// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__FLOAT32_HPP_
#define EXAMPLE_INTERFACES__MSG__FLOAT32_HPP_

#include "example_interfaces/msg/detail/float32__struct.hpp"
#include "example_interfaces/msg/detail/float32__builder.hpp"
#include "example_interfaces/msg/detail/float32__traits.hpp"
#include "example_interfaces/msg/detail/float32__type_support.hpp"

#endif  // EXAMPLE_INTERFACES__MSG__FLOAT32_HPP_
