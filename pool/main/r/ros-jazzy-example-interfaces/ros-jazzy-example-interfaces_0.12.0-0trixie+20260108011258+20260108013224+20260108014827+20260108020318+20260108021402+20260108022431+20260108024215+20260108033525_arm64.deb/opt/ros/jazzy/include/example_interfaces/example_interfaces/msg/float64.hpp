// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__FLOAT64_HPP_
#define EXAMPLE_INTERFACES__MSG__FLOAT64_HPP_

#include "example_interfaces/msg/detail/float64__struct.hpp"
#include "example_interfaces/msg/detail/float64__builder.hpp"
#include "example_interfaces/msg/detail/float64__traits.hpp"
#include "example_interfaces/msg/detail/float64__type_support.hpp"

#endif  // EXAMPLE_INTERFACES__MSG__FLOAT64_HPP_
