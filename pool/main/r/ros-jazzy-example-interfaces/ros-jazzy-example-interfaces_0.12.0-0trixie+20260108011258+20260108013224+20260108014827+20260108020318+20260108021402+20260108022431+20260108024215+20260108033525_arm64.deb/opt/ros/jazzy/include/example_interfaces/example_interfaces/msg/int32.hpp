// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__INT32_HPP_
#define EXAMPLE_INTERFACES__MSG__INT32_HPP_

#include "example_interfaces/msg/detail/int32__struct.hpp"
#include "example_interfaces/msg/detail/int32__builder.hpp"
#include "example_interfaces/msg/detail/int32__traits.hpp"
#include "example_interfaces/msg/detail/int32__type_support.hpp"

#endif  // EXAMPLE_INTERFACES__MSG__INT32_HPP_
