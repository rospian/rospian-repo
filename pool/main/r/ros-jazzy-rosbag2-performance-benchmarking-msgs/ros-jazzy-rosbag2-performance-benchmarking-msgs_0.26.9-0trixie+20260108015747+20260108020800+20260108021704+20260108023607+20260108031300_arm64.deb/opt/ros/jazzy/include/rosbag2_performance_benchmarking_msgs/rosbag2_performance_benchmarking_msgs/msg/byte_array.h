// generated from rosidl_generator_c/resource/idl.h.em
// with input from rosbag2_performance_benchmarking_msgs:msg/ByteArray.idl
// generated code does not contain a copyright notice

#ifndef ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_H_
#define ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_H_

#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__struct.h"
#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__functions.h"
#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__type_support.h"

#endif  // ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_H_
