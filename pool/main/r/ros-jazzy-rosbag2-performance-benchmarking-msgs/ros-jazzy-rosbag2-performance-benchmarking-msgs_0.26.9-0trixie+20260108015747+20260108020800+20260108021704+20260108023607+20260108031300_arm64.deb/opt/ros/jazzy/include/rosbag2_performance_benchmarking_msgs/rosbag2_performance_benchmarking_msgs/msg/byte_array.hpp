// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_HPP_
#define ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_HPP_

#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__struct.hpp"
#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__builder.hpp"
#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__traits.hpp"
#include "rosbag2_performance_benchmarking_msgs/msg/detail/byte_array__type_support.hpp"

#endif  // ROSBAG2_PERFORMANCE_BENCHMARKING_MSGS__MSG__BYTE_ARRAY_HPP_
