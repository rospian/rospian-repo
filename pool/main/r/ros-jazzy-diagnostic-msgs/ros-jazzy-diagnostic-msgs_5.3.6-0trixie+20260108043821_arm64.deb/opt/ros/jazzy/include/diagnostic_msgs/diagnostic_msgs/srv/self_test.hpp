// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DIAGNOSTIC_MSGS__SRV__SELF_TEST_HPP_
#define DIAGNOSTIC_MSGS__SRV__SELF_TEST_HPP_

#include "diagnostic_msgs/srv/detail/self_test__struct.hpp"
#include "diagnostic_msgs/srv/detail/self_test__builder.hpp"
#include "diagnostic_msgs/srv/detail/self_test__traits.hpp"
#include "diagnostic_msgs/srv/detail/self_test__type_support.hpp"

#endif  // DIAGNOSTIC_MSGS__SRV__SELF_TEST_HPP_
