#include "OgrePrerequisites.h"
#include "OgreIteratorWrapper.h"
#pragma message( __FILE__ " is deprecated, migrate to OgreIteratorWrapper.h")
