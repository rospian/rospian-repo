#pragma once
#define IMGUI_DISABLE_OBSOLETE_FUNCTIONS
#include <OgreOverlayPrerequisites.h>
#define IMGUI_API _OgreOverlayExport