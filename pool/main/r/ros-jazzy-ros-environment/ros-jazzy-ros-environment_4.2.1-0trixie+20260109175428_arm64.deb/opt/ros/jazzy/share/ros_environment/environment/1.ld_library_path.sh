# generated from ros_environment/env-hooks/1.ld_library_path.sh.in

ament_prepend_unique_value LD_LIBRARY_PATH "/opt/ros/jazzy/lib/aarch64-linux-gnu"
