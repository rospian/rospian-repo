# generated from ros_environment/env-hooks/1.ros_discovery.sh.in

if [ -n "$ROS_AUTOMATIC_DISCOVERY_RANGE" ]; then
  export ROS_AUTOMATIC_DISCOVERY_RANGE=SUBNET
fi
