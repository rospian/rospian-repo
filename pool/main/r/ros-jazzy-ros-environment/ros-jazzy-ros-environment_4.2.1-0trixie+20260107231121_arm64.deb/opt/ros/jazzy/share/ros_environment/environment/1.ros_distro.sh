# generated from ros_environment/env-hooks/1.ros_distro.sh.in

export ROS_DISTRO=jazzy
