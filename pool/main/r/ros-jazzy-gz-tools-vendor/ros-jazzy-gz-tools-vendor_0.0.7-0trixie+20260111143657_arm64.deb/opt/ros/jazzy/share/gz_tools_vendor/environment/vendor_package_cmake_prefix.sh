# generated from ament_cmake_vendor_package/cmake/templates/vendor_package_cmake_prefix.sh.in

ament_prepend_unique_value CMAKE_PREFIX_PATH "$AMENT_CURRENT_PREFIX/opt/gz_tools_vendor"
