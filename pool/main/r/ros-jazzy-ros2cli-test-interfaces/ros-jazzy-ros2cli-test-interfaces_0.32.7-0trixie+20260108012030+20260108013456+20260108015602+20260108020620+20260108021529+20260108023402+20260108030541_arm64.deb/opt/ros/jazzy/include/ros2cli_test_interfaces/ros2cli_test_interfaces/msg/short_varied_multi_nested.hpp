// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_MULTI_NESTED_HPP_
#define ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_MULTI_NESTED_HPP_

#include "ros2cli_test_interfaces/msg/detail/short_varied_multi_nested__struct.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied_multi_nested__builder.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied_multi_nested__traits.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied_multi_nested__type_support.hpp"

#endif  // ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_MULTI_NESTED_HPP_
