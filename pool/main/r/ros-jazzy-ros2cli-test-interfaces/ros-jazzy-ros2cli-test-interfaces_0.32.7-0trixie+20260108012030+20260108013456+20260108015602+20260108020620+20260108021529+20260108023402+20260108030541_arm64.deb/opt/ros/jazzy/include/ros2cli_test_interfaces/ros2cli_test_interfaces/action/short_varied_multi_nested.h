// generated from rosidl_generator_c/resource/idl.h.em
// with input from ros2cli_test_interfaces:action/ShortVariedMultiNested.idl
// generated code does not contain a copyright notice

#ifndef ROS2CLI_TEST_INTERFACES__ACTION__SHORT_VARIED_MULTI_NESTED_H_
#define ROS2CLI_TEST_INTERFACES__ACTION__SHORT_VARIED_MULTI_NESTED_H_

#include "ros2cli_test_interfaces/action/detail/short_varied_multi_nested__struct.h"
#include "ros2cli_test_interfaces/action/detail/short_varied_multi_nested__functions.h"
#include "ros2cli_test_interfaces/action/detail/short_varied_multi_nested__type_support.h"

#endif  // ROS2CLI_TEST_INTERFACES__ACTION__SHORT_VARIED_MULTI_NESTED_H_
