// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_HPP_
#define ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_HPP_

#include "ros2cli_test_interfaces/msg/detail/short_varied__struct.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied__builder.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied__traits.hpp"
#include "ros2cli_test_interfaces/msg/detail/short_varied__type_support.hpp"

#endif  // ROS2CLI_TEST_INTERFACES__MSG__SHORT_VARIED_HPP_
