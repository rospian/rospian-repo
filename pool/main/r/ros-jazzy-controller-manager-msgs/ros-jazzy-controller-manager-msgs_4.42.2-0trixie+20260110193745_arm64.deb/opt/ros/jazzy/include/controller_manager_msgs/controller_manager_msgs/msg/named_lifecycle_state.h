// generated from rosidl_generator_c/resource/idl.h.em
// with input from controller_manager_msgs:msg/NamedLifecycleState.idl
// generated code does not contain a copyright notice

#ifndef CONTROLLER_MANAGER_MSGS__MSG__NAMED_LIFECYCLE_STATE_H_
#define CONTROLLER_MANAGER_MSGS__MSG__NAMED_LIFECYCLE_STATE_H_

#include "controller_manager_msgs/msg/detail/named_lifecycle_state__struct.h"
#include "controller_manager_msgs/msg/detail/named_lifecycle_state__functions.h"
#include "controller_manager_msgs/msg/detail/named_lifecycle_state__type_support.h"

#endif  // CONTROLLER_MANAGER_MSGS__MSG__NAMED_LIFECYCLE_STATE_H_
