// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROLLER_MANAGER_MSGS__MSG__CONTROLLER_MANAGER_ACTIVITY_HPP_
#define CONTROLLER_MANAGER_MSGS__MSG__CONTROLLER_MANAGER_ACTIVITY_HPP_

#include "controller_manager_msgs/msg/detail/controller_manager_activity__struct.hpp"
#include "controller_manager_msgs/msg/detail/controller_manager_activity__builder.hpp"
#include "controller_manager_msgs/msg/detail/controller_manager_activity__traits.hpp"
#include "controller_manager_msgs/msg/detail/controller_manager_activity__type_support.hpp"

#endif  // CONTROLLER_MANAGER_MSGS__MSG__CONTROLLER_MANAGER_ACTIVITY_HPP_
