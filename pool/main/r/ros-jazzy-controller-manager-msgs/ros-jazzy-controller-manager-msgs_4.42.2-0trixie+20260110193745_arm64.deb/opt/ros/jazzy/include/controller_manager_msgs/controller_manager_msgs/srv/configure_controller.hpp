// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROLLER_MANAGER_MSGS__SRV__CONFIGURE_CONTROLLER_HPP_
#define CONTROLLER_MANAGER_MSGS__SRV__CONFIGURE_CONTROLLER_HPP_

#include "controller_manager_msgs/srv/detail/configure_controller__struct.hpp"
#include "controller_manager_msgs/srv/detail/configure_controller__builder.hpp"
#include "controller_manager_msgs/srv/detail/configure_controller__traits.hpp"
#include "controller_manager_msgs/srv/detail/configure_controller__type_support.hpp"

#endif  // CONTROLLER_MANAGER_MSGS__SRV__CONFIGURE_CONTROLLER_HPP_
