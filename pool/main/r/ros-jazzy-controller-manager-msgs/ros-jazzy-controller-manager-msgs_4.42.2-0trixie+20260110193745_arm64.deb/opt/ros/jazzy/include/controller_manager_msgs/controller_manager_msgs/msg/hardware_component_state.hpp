// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROLLER_MANAGER_MSGS__MSG__HARDWARE_COMPONENT_STATE_HPP_
#define CONTROLLER_MANAGER_MSGS__MSG__HARDWARE_COMPONENT_STATE_HPP_

#include "controller_manager_msgs/msg/detail/hardware_component_state__struct.hpp"
#include "controller_manager_msgs/msg/detail/hardware_component_state__builder.hpp"
#include "controller_manager_msgs/msg/detail/hardware_component_state__traits.hpp"
#include "controller_manager_msgs/msg/detail/hardware_component_state__type_support.hpp"

#endif  // CONTROLLER_MANAGER_MSGS__MSG__HARDWARE_COMPONENT_STATE_HPP_
