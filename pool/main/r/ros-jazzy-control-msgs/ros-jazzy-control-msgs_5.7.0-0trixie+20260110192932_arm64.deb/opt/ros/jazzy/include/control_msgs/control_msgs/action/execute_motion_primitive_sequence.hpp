// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_HPP_
#define CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_HPP_

#include "control_msgs/action/detail/execute_motion_primitive_sequence__struct.hpp"
#include "control_msgs/action/detail/execute_motion_primitive_sequence__builder.hpp"
#include "control_msgs/action/detail/execute_motion_primitive_sequence__traits.hpp"
#include "control_msgs/action/detail/execute_motion_primitive_sequence__type_support.hpp"

#endif  // CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_HPP_
