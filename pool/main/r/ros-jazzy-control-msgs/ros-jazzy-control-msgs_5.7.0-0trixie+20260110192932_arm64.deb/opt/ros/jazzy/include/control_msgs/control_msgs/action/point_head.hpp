// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__POINT_HEAD_HPP_
#define CONTROL_MSGS__ACTION__POINT_HEAD_HPP_

#include "control_msgs/action/detail/point_head__struct.hpp"
#include "control_msgs/action/detail/point_head__builder.hpp"
#include "control_msgs/action/detail/point_head__traits.hpp"
#include "control_msgs/action/detail/point_head__type_support.hpp"

#endif  // CONTROL_MSGS__ACTION__POINT_HEAD_HPP_
