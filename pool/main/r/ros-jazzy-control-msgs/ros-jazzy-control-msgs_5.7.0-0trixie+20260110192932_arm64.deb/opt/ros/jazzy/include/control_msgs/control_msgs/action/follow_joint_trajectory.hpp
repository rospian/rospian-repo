// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__FOLLOW_JOINT_TRAJECTORY_HPP_
#define CONTROL_MSGS__ACTION__FOLLOW_JOINT_TRAJECTORY_HPP_

#include "control_msgs/action/detail/follow_joint_trajectory__struct.hpp"
#include "control_msgs/action/detail/follow_joint_trajectory__builder.hpp"
#include "control_msgs/action/detail/follow_joint_trajectory__traits.hpp"
#include "control_msgs/action/detail/follow_joint_trajectory__type_support.hpp"

#endif  // CONTROL_MSGS__ACTION__FOLLOW_JOINT_TRAJECTORY_HPP_
