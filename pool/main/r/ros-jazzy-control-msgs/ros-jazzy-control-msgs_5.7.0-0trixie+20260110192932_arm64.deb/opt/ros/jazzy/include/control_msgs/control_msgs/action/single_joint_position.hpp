// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_HPP_
#define CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_HPP_

#include "control_msgs/action/detail/single_joint_position__struct.hpp"
#include "control_msgs/action/detail/single_joint_position__builder.hpp"
#include "control_msgs/action/detail/single_joint_position__traits.hpp"
#include "control_msgs/action/detail/single_joint_position__type_support.hpp"

#endif  // CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_HPP_
