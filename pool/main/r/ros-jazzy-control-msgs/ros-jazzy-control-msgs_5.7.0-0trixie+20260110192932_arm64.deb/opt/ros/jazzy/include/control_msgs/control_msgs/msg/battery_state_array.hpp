// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__MSG__BATTERY_STATE_ARRAY_HPP_
#define CONTROL_MSGS__MSG__BATTERY_STATE_ARRAY_HPP_

#include "control_msgs/msg/detail/battery_state_array__struct.hpp"
#include "control_msgs/msg/detail/battery_state_array__builder.hpp"
#include "control_msgs/msg/detail/battery_state_array__traits.hpp"
#include "control_msgs/msg/detail/battery_state_array__type_support.hpp"

#endif  // CONTROL_MSGS__MSG__BATTERY_STATE_ARRAY_HPP_
