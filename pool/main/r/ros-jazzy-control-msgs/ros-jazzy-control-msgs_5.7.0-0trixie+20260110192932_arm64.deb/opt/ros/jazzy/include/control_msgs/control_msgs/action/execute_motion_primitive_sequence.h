// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:action/ExecuteMotionPrimitiveSequence.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_H_
#define CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_H_

#include "control_msgs/action/detail/execute_motion_primitive_sequence__struct.h"
#include "control_msgs/action/detail/execute_motion_primitive_sequence__functions.h"
#include "control_msgs/action/detail/execute_motion_primitive_sequence__type_support.h"

#endif  // CONTROL_MSGS__ACTION__EXECUTE_MOTION_PRIMITIVE_SEQUENCE_H_
