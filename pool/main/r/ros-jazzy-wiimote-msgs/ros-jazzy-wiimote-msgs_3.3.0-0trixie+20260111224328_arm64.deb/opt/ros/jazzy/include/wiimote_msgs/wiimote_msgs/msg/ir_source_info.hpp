// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_HPP_
#define WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_HPP_

#include "wiimote_msgs/msg/detail/ir_source_info__struct.hpp"
#include "wiimote_msgs/msg/detail/ir_source_info__builder.hpp"
#include "wiimote_msgs/msg/detail/ir_source_info__traits.hpp"
#include "wiimote_msgs/msg/detail/ir_source_info__type_support.hpp"

#endif  // WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_HPP_
