// generated from rosidl_generator_c/resource/idl.h.em
// with input from wiimote_msgs:msg/TimedSwitch.idl
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__TIMED_SWITCH_H_
#define WIIMOTE_MSGS__MSG__TIMED_SWITCH_H_

#include "wiimote_msgs/msg/detail/timed_switch__struct.h"
#include "wiimote_msgs/msg/detail/timed_switch__functions.h"
#include "wiimote_msgs/msg/detail/timed_switch__type_support.h"

#endif  // WIIMOTE_MSGS__MSG__TIMED_SWITCH_H_
