// generated from rosidl_generator_c/resource/idl.h.em
// with input from wiimote_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__STATE_H_
#define WIIMOTE_MSGS__MSG__STATE_H_

#include "wiimote_msgs/msg/detail/state__struct.h"
#include "wiimote_msgs/msg/detail/state__functions.h"
#include "wiimote_msgs/msg/detail/state__type_support.h"

#endif  // WIIMOTE_MSGS__MSG__STATE_H_
