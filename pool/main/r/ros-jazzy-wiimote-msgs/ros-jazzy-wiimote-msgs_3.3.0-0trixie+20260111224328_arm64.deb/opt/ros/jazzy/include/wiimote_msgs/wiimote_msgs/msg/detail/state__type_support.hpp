// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from wiimote_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__DETAIL__STATE__TYPE_SUPPORT_HPP_
#define WIIMOTE_MSGS__MSG__DETAIL__STATE__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "wiimote_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_wiimote_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  wiimote_msgs,
  msg,
  State
)();
#ifdef __cplusplus
}
#endif

#endif  // WIIMOTE_MSGS__MSG__DETAIL__STATE__TYPE_SUPPORT_HPP_
