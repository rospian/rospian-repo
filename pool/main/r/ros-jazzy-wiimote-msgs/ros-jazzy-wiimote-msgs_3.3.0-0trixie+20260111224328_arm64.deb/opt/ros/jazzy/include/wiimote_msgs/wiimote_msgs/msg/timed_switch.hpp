// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__TIMED_SWITCH_HPP_
#define WIIMOTE_MSGS__MSG__TIMED_SWITCH_HPP_

#include "wiimote_msgs/msg/detail/timed_switch__struct.hpp"
#include "wiimote_msgs/msg/detail/timed_switch__builder.hpp"
#include "wiimote_msgs/msg/detail/timed_switch__traits.hpp"
#include "wiimote_msgs/msg/detail/timed_switch__type_support.hpp"

#endif  // WIIMOTE_MSGS__MSG__TIMED_SWITCH_HPP_
