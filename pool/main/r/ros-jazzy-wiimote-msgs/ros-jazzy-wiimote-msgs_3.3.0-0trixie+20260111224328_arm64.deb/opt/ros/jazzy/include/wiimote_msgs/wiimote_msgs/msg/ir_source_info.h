// generated from rosidl_generator_c/resource/idl.h.em
// with input from wiimote_msgs:msg/IrSourceInfo.idl
// generated code does not contain a copyright notice

#ifndef WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_H_
#define WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_H_

#include "wiimote_msgs/msg/detail/ir_source_info__struct.h"
#include "wiimote_msgs/msg/detail/ir_source_info__functions.h"
#include "wiimote_msgs/msg/detail/ir_source_info__type_support.h"

#endif  // WIIMOTE_MSGS__MSG__IR_SOURCE_INFO_H_
